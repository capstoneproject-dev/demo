<?php
/**
 * QR Attendance domain services.
 * Org-scoped helpers for api/qr-attendance endpoints.
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/upload_security.php';
require_once __DIR__ . '/system_settings.php';

class QrAttendanceValidationException extends RuntimeException {}
class QrAttendanceAuthorizationException extends RuntimeException {}

function qrAttendanceColumnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*)
         FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = :table_name
           AND COLUMN_NAME = :column_name"
    );
    $stmt->execute([
        ':table_name' => $table,
        ':column_name' => $column,
    ]);
    return ((int)$stmt->fetchColumn() > 0);
}

function qrEnsureEventArchiveColumns(PDO $pdo): void
{
    static $ensuredConnections = [];
    $connectionId = spl_object_id($pdo);
    if (!empty($ensuredConnections[$connectionId])) {
        return;
    }

    $columns = [
        'archived_at' => "ALTER TABLE events ADD COLUMN archived_at DATETIME NULL AFTER is_published",
        'archived_by_user_id' => "ALTER TABLE events ADD COLUMN archived_by_user_id INT NULL AFTER archived_at",
        'academic_year' => "ALTER TABLE events ADD COLUMN academic_year VARCHAR(9) NULL AFTER is_published",
        'semester' => "ALTER TABLE events ADD COLUMN semester ENUM('1st','2nd') NULL AFTER academic_year",
        'grading_period' => "ALTER TABLE events ADD COLUMN grading_period ENUM('prelim','midterm','finals') NULL AFTER semester",
    ];
    foreach ($columns as $column => $alterSql) {
        if (!qrAttendanceColumnExists($pdo, 'events', $column)) {
            $pdo->exec($alterSql);
        }
    }

    $indexStmt = $pdo->query(
        "SELECT COUNT(*)
         FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'events'
           AND INDEX_NAME = 'idx_events_org_archive_sort'"
    );
    if ((int)$indexStmt->fetchColumn() === 0) {
        $pdo->exec(
            "ALTER TABLE events
             ADD INDEX idx_events_org_archive_sort (org_id, archived_at, event_datetime, event_id)"
        );
    }

    $termIndexStmt = $pdo->query(
        "SELECT COUNT(*)
         FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'events'
           AND INDEX_NAME = 'idx_events_org_academic_term'"
    );
    if ((int)$termIndexStmt->fetchColumn() === 0) {
        $pdo->exec(
            "ALTER TABLE events
             ADD INDEX idx_events_org_academic_term
                (org_id, academic_year, semester, grading_period, archived_at, event_datetime)"
        );
    }

    $constraintStmt = $pdo->query(
        "SELECT COUNT(*)
         FROM information_schema.TABLE_CONSTRAINTS
         WHERE CONSTRAINT_SCHEMA = DATABASE()
           AND TABLE_NAME = 'events'
           AND CONSTRAINT_NAME = 'fk_events_archiver'
           AND CONSTRAINT_TYPE = 'FOREIGN KEY'"
    );
    if ((int)$constraintStmt->fetchColumn() === 0) {
        $pdo->exec(
            "ALTER TABLE events
             ADD CONSTRAINT fk_events_archiver
             FOREIGN KEY (archived_by_user_id) REFERENCES users(user_id) ON DELETE SET NULL"
        );
    }

    // Events created before term auditing was introduced receive the active
    // OSA term once. New events snapshot the term when they are created.
    $activeTerm = settingsGetActiveAcademicTerm($pdo);
    $backfill = $pdo->prepare(
        "UPDATE events
         SET academic_year = :academic_year,
             semester = :semester,
             grading_period = :grading_period
         WHERE academic_year IS NULL
            OR semester IS NULL
            OR grading_period IS NULL"
    );
    $backfill->execute([
        ':academic_year' => $activeTerm['academic_year'],
        ':semester' => $activeTerm['semester'],
        ':grading_period' => $activeTerm['grading_period'],
    ]);

    $ensuredConnections[$connectionId] = true;
}

function qrEnsureOfflineAttendanceColumns(PDO $pdo): void
{
    static $ensuredConnections = [];
    $connectionId = spl_object_id($pdo);
    if (!empty($ensuredConnections[$connectionId])) return;
    $columns = [
        'check_in_received_at' => "ALTER TABLE attendance_records ADD COLUMN check_in_received_at DATETIME NULL AFTER time_in",
        'check_out_received_at' => "ALTER TABLE attendance_records ADD COLUMN check_out_received_at DATETIME NULL AFTER time_out",
    ];
    foreach ($columns as $column => $sql) {
        if (!qrAttendanceColumnExists($pdo, 'attendance_records', $column)) $pdo->exec($sql);
    }
    $ensuredConnections[$connectionId] = true;
}

/** @return array{captured:DateTimeImmutable,received:DateTimeImmutable,is_offline:bool} */
function qrAttendanceCaptureTimes(PDO $pdo, array $data): array
{
    qrEnsureOfflineAttendanceColumns($pdo);
    $tz = new DateTimeZone('Asia/Manila');
    $received = new DateTimeImmutable('now', $tz);
    $raw = trim((string)($data['captured_at'] ?? ''));
    if ($raw === '') return ['captured' => $received, 'received' => $received, 'is_offline' => false];
    try {
        $captured = (new DateTimeImmutable($raw))->setTimezone($tz);
    } catch (Throwable $_) {
        throw new QrAttendanceValidationException('Invalid offline attendance timestamp.');
    }
    if ($captured < $received->modify('-7 days')) {
        throw new QrAttendanceValidationException('Offline attendance timestamps more than seven days old are not accepted.');
    }
    if ($captured > $received->modify('+5 minutes')) {
        throw new QrAttendanceValidationException('Offline attendance timestamps more than five minutes in the future are not accepted.');
    }
    return ['captured' => $captured, 'received' => $received, 'is_offline' => true];
}

function qrRequireOfficerOrgContext(): array
{
    $session = getPhpSession();
    if (!isLoggedIn()) {
        throw new QrAttendanceAuthorizationException('Not authenticated.');
    }
    if (($session['login_role'] ?? null) !== 'org') {
        throw new QrAttendanceAuthorizationException('Officer organization context required.');
    }
    $orgId = (int)($session['active_org_id'] ?? 0);
    if ($orgId <= 0) {
        throw new QrAttendanceAuthorizationException('No active organization selected.');
    }

    return [
        'session' => $session,
        'org_id' => $orgId,
        'user_id' => (int)($session['user_id'] ?? 0),
    ];
}

function qrSplitFullName(string $fullName): array
{
    $name = trim($fullName);
    if ($name === '') {
        return ['Student', 'User'];
    }
    $parts = preg_split('/\s+/', $name);
    if (!$parts || count($parts) === 1) {
        return [$parts[0] ?? 'Student', '-'];
    }
    $first = array_shift($parts);
    $last = implode(' ', $parts);
    return [$first, $last];
}

function qrSaveEventPhotoFromData(string $photoValue): string
{
    $raw = trim($photoValue);
    if ($raw === '') {
        return '';
    }

    if (!str_starts_with($raw, 'data:')) {
        if (!preg_match('#^uploads/events/[A-Za-z0-9._-]+$#', $raw)) {
            throw new QrAttendanceValidationException('Invalid event photo path.');
        }
        return $raw;
    }

    $allowed = [
        'image/png' => 'png',
        'image/jpeg' => 'jpg',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];
    try {
        return uploadStoreImageDataUrl(
            $raw,
            'events',
            'event',
            $allowed,
            5 * 1024 * 1024,
            8000
        );
    } catch (UploadValidationException $e) {
        throw new QrAttendanceValidationException($e->getMessage(), 0, $e);
    }
}

function qrListEvents(PDO $pdo, int $orgId, array $filters = []): array
{
    qrEnsureEventArchiveColumns($pdo);
    $where = ["e.org_id = :org"];
    $params = [':org' => $orgId];

    $state = strtolower(trim((string)($filters['state'] ?? 'active')));
    if ($state === 'archived') {
        $where[] = 'e.archived_at IS NOT NULL';
    } elseif ($state !== 'all') {
        $where[] = 'e.archived_at IS NULL';
    }

    $q = trim((string)($filters['q'] ?? ''));
    if ($q !== '') {
        $where[] = "(e.event_name LIKE :q_name OR e.description LIKE :q_desc OR e.location LIKE :q_loc)";
        $qLike = '%' . $q . '%';
        $params[':q_name'] = $qLike;
        $params[':q_desc'] = $qLike;
        $params[':q_loc'] = $qLike;
    }

    if (!empty($filters['academic_year'])) {
        $where[] = 'e.academic_year = :academic_year';
        $params[':academic_year'] = settingsValidateAcademicYear($filters['academic_year']);
    }
    if (!empty($filters['semester'])) {
        $where[] = 'e.semester = :semester';
        $params[':semester'] = settingsValidateSemester($filters['semester']);
    }
    if (!empty($filters['grading_period'])) {
        $where[] = 'e.grading_period = :grading_period';
        $params[':grading_period'] = settingsValidateGradingPeriod($filters['grading_period']);
    }

    $sql = "
        SELECT e.event_id,
               e.org_id,
               e.created_by_user_id,
               e.event_name,
               e.description,
               e.location,
               e.event_datetime,
               e.event_photo,
               e.event_datetime AS event_date,
               e.is_published,
               e.academic_year,
               e.semester,
               e.grading_period,
               e.archived_at,
               e.archived_by_user_id,
               e.created_at,
               e.updated_at,
               COUNT(ar.record_id) AS attendance_count,
               COALESCE(SUM(CASE WHEN ar.time_in IS NULL AND ar.time_out IS NULL THEN 1 ELSE 0 END), 0) AS pre_registered_count,
               COALESCE(SUM(CASE WHEN ar.time_in IS NOT NULL OR ar.time_out IS NOT NULL THEN 1 ELSE 0 END), 0) AS attended_count,
               MIN(DATE(ar.time_in)) AS first_record_date,
               MAX(DATE(ar.time_in)) AS last_record_date,
               COALESCE(MIN(DATE(ar.time_in)), DATE(e.event_datetime)) AS archive_start_date,
               COALESCE(MAX(DATE(ar.time_in)), DATE(e.event_datetime)) AS archive_end_date
        FROM events e
        LEFT JOIN attendance_records ar ON ar.event_id = e.event_id
        WHERE " . implode(' AND ', $where) . "
        GROUP BY e.event_id
        ORDER BY COALESCE(MIN(ar.time_in), e.event_datetime) DESC,
                 COALESCE(MAX(ar.time_in), e.event_datetime) DESC,
                 e.event_id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['event_id'] = (int)$row['event_id'];
        $row['org_id'] = (int)$row['org_id'];
        $row['created_by_user_id'] = (int)$row['created_by_user_id'];
        $row['archived_by_user_id'] = $row['archived_by_user_id'] !== null
            ? (int)$row['archived_by_user_id']
            : null;
        $row['is_published'] = (int)$row['is_published'];
        $row['attendance_count'] = (int)$row['attendance_count'];
    }
    return $rows;
}

function qrListPublishedEventsForStudents(PDO $pdo, array $filters = []): array
{
    qrEnsureEventArchiveColumns($pdo);
    $where = [
        'e.is_published = 1',
        'e.archived_at IS NULL',
    ];
    $params = [];

    $q = trim((string)($filters['q'] ?? ''));
    if ($q !== '') {
        $where[] = "(e.event_name LIKE :q_name OR e.description LIKE :q_desc OR e.location LIKE :q_loc OR o.org_name LIKE :q_org)";
        $qLike = '%' . $q . '%';
        $params[':q_name'] = $qLike;
        $params[':q_desc'] = $qLike;
        $params[':q_loc'] = $qLike;
        $params[':q_org'] = $qLike;
    }

    $sql = "
        SELECT e.event_id,
               e.org_id,
               e.created_by_user_id,
               e.event_name,
               e.description,
               e.location,
               e.event_datetime,
               e.event_photo,
               (
                   SELECT a.announcement_photo
                   FROM announcements a
                   WHERE a.org_id = e.org_id
                     AND a.title COLLATE utf8mb4_unicode_ci = e.event_name COLLATE utf8mb4_unicode_ci
                   ORDER BY a.announcement_id DESC
                   LIMIT 1
               ) AS synced_announcement_photo,
               e.event_datetime AS event_date,
               e.is_published,
               e.created_at,
               e.updated_at,
               o.org_name,
               o.org_code,
               COUNT(ar.record_id) AS attendance_count,
               COALESCE(SUM(CASE WHEN ar.time_in IS NULL AND ar.time_out IS NULL THEN 1 ELSE 0 END), 0) AS pre_registered_count,
               COALESCE(SUM(CASE WHEN ar.time_in IS NOT NULL OR ar.time_out IS NOT NULL THEN 1 ELSE 0 END), 0) AS attended_count
        FROM events e
        JOIN organizations o ON o.org_id = e.org_id
        LEFT JOIN attendance_records ar ON ar.event_id = e.event_id
        WHERE " . implode(' AND ', $where) . "
        GROUP BY e.event_id, o.org_name, o.org_code
        ORDER BY e.event_datetime ASC, e.event_id ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['event_id'] = (int)$row['event_id'];
        $row['org_id'] = (int)$row['org_id'];
        $row['created_by_user_id'] = (int)$row['created_by_user_id'];
        $row['is_published'] = (int)$row['is_published'];
        $row['attendance_count'] = (int)$row['attendance_count'];
        $row['pre_registered_count'] = (int)$row['pre_registered_count'];
        $row['attended_count'] = (int)$row['attended_count'];
    }
    return $rows;
}

function qrSaveEvent(PDO $pdo, int $orgId, int $userId, array $data): int
{
    qrEnsureEventArchiveColumns($pdo);
    $eventId = isset($data['event_id']) ? (int)$data['event_id'] : 0;
    $eventName = preg_replace('/\s+/u', ' ', trim((string)($data['event_name'] ?? $data['name'] ?? ''))) ?? '';
    $description = trim((string)($data['description'] ?? ''));
    $locationProvided = array_key_exists('location', $data);
    $location = $locationProvided && $data['location'] === null
        ? null
        : trim((string)($data['location'] ?? ''));
    $eventDateProvided = array_key_exists('event_datetime', $data) || array_key_exists('event_date', $data);
    $eventDateValue = array_key_exists('event_datetime', $data) ? $data['event_datetime'] : ($data['event_date'] ?? '');
    $eventDate = $eventDateProvided && $eventDateValue === null
        ? null
        : trim((string)$eventDateValue);
    $isPublished = !empty($data['is_published']) ? 1 : 0;
    $photoValues = $data['photos'] ?? $data['event_photos'] ?? null;
    $singlePhoto = trim((string)($data['photo'] ?? ''));
    if (!is_array($photoValues) || (!$photoValues && $singlePhoto !== '')) {
        $photoValues = $singlePhoto !== '' ? [$singlePhoto] : [];
    }
    $photoPath = '';

    if ($eventName === '') {
        throw new QrAttendanceValidationException('event_name is required.');
    }
    if ($userId <= 0) {
        throw new QrAttendanceValidationException('Invalid processor user.');
    }

    // Event names are organization-wide identifiers for attendance. Prevent
    // active, archived, online, and offline-synchronized records from
    // resolving to different events solely because of case or extra spacing.
    $duplicateCheck = $pdo->prepare(
        "SELECT event_id, event_name
         FROM events
         WHERE org_id = :org
           AND event_id <> :current_id"
    );
    $duplicateCheck->execute([
        ':org' => $orgId,
        ':current_id' => $eventId,
    ]);
    $canonicalName = function_exists('mb_strtolower') ? mb_strtolower($eventName, 'UTF-8') : strtolower($eventName);
    foreach ($duplicateCheck->fetchAll() as $candidate) {
        $candidateName = preg_replace('/\s+/u', ' ', trim((string)($candidate['event_name'] ?? ''))) ?? '';
        $candidateName = function_exists('mb_strtolower') ? mb_strtolower($candidateName, 'UTF-8') : strtolower($candidateName);
        if ($candidateName === $canonicalName) {
            throw new QrAttendanceValidationException('An event with this name already exists. Use a different event name.');
        }
    }

    if ($photoValues) {
        $savedPhotos = [];
        foreach ($photoValues as $photoValue) {
            $savedPath = qrSaveEventPhotoFromData((string)$photoValue);
            if ($savedPath !== '') {
                $savedPhotos[] = $savedPath;
            }
        }
        if ($savedPhotos) {
            $photoPath = json_encode(array_values(array_unique($savedPhotos)), JSON_UNESCAPED_SLASHES);
        }
    }

    $tz = new DateTimeZone('Asia/Manila');
    $now = new DateTimeImmutable('now', $tz);
    if ($eventDate === null) {
        // Keep explicit nulls from simple event creation instead of inventing a date.
    } elseif ($eventDate === '') {
        $eventDate = $now->format('Y-m-d H:i:s');
    } else {
        // Accept "YYYY-MM-DD", "YYYY-MM-DD HH:MM", or ISO "YYYY-MM-DDTHH:MM"
        $normalized = str_replace('T', ' ', $eventDate);
        // If only date was provided, add 00:00
        if (preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $normalized)) {
            $normalized .= ' 00:00:00';
        }
        // If date + time without seconds
        if (preg_match('/^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}$/', $normalized)) {
            $normalized .= ':00';
        }
        try {
            $dt = new DateTimeImmutable($normalized, $tz);
            $eventDate = $dt->format('Y-m-d H:i:s');
        } catch (Exception $_) {
            throw new QrAttendanceValidationException('Invalid event_datetime format.');
        }
    }
    if ($location === '') $location = 'TBA';

    if ($eventId > 0) {
        $chk = $pdo->prepare("SELECT event_id, event_photo FROM events WHERE event_id = :id AND org_id = :org AND archived_at IS NULL LIMIT 1");
        $chk->execute([':id' => $eventId, ':org' => $orgId]);
        $existing = $chk->fetch();
        if (!$existing) {
            throw new QrAttendanceValidationException('Event not found for this organization.');
        }
        if ($photoPath === '') {
            $photoPath = trim((string)($existing['event_photo'] ?? ''));
        }

        $upd = $pdo->prepare(
            "UPDATE events
             SET event_name = :name,
                 description = :description,
                 location = :location,
                 event_datetime = :event_datetime,
                 event_photo = :event_photo,
                 is_published = :is_published
             WHERE event_id = :id AND org_id = :org"
        );
        $upd->execute([
            ':name' => $eventName,
            ':description' => $description !== '' ? $description : null,
            ':location' => $location,
            ':event_datetime' => $eventDate,
            ':event_photo' => $photoPath !== '' ? $photoPath : null,
            ':is_published' => $isPublished,
            ':id' => $eventId,
            ':org' => $orgId,
        ]);
        return $eventId;
    }

    $activeTerm = settingsGetActiveAcademicTerm($pdo);
    $ins = $pdo->prepare(
        "INSERT INTO events
            (org_id, created_by_user_id, event_name, description, location, event_datetime, event_photo, is_published,
             academic_year, semester, grading_period)
         VALUES
            (:org, :uid, :name, :description, :location, :event_datetime, :event_photo, :is_published,
             :academic_year, :semester, :grading_period)"
    );
    $ins->execute([
        ':org' => $orgId,
        ':uid' => $userId,
        ':name' => $eventName,
        ':description' => $description !== '' ? $description : null,
        ':location' => $location,
        ':event_datetime' => $eventDate,
        ':event_photo' => $photoPath !== '' ? $photoPath : null,
        ':is_published' => $isPublished,
        ':academic_year' => $activeTerm['academic_year'],
        ':semester' => $activeTerm['semester'],
        ':grading_period' => $activeTerm['grading_period'],
    ]);
    return (int)$pdo->lastInsertId();
}

function qrDeleteEvent(PDO $pdo, int $orgId, int $eventId): void
{
    if ($eventId <= 0) {
        throw new QrAttendanceValidationException('Invalid event_id.');
    }
    $del = $pdo->prepare("DELETE FROM events WHERE event_id = :id AND org_id = :org");
    $del->execute([':id' => $eventId, ':org' => $orgId]);
    if ($del->rowCount() === 0) {
        throw new QrAttendanceValidationException('Event not found for this organization.');
    }
}

function qrSetEventArchived(PDO $pdo, int $orgId, int $userId, int $eventId, string $action): void
{
    qrEnsureEventArchiveColumns($pdo);
    if ($eventId <= 0) {
        throw new QrAttendanceValidationException('Invalid event_id.');
    }
    if ($userId <= 0) {
        throw new QrAttendanceValidationException('Invalid officer user.');
    }

    $normalizedAction = strtolower(trim($action));
    if (!in_array($normalizedAction, ['archive', 'restore'], true)) {
        throw new QrAttendanceValidationException('action must be archive or restore.');
    }

    if ($normalizedAction === 'archive') {
        $stmt = $pdo->prepare(
            "UPDATE events
             SET archived_at = CURRENT_TIMESTAMP,
                 archived_by_user_id = :user_id
             WHERE event_id = :event_id
               AND org_id = :org_id
               AND archived_at IS NULL"
        );
        $stmt->execute([
            ':user_id' => $userId,
            ':event_id' => $eventId,
            ':org_id' => $orgId,
        ]);
    } else {
        $stmt = $pdo->prepare(
            "UPDATE events
             SET archived_at = NULL,
                 archived_by_user_id = NULL
             WHERE event_id = :event_id
               AND org_id = :org_id
               AND archived_at IS NOT NULL"
        );
        $stmt->execute([
            ':event_id' => $eventId,
            ':org_id' => $orgId,
        ]);
    }

    if ($stmt->rowCount() !== 1) {
        throw new QrAttendanceValidationException(
            $normalizedAction === 'archive'
                ? 'Active event not found for this organization.'
                : 'Archived event not found for this organization.'
        );
    }
}

function qrFindEventIdByName(PDO $pdo, int $orgId, string $eventName): ?int
{
    qrEnsureEventArchiveColumns($pdo);
    $name = trim($eventName);
    if ($name === '') return null;

    $stmt = $pdo->prepare(
        "SELECT event_id
         FROM events
         WHERE org_id = :org AND event_name = :name AND archived_at IS NULL
         ORDER BY event_datetime DESC, event_id DESC
         LIMIT 1"
    );
    $stmt->execute([':org' => $orgId, ':name' => $name]);
    $row = $stmt->fetch();
    return $row ? (int)$row['event_id'] : null;
}

function qrResolveEventId(PDO $pdo, int $orgId, int $userId, array $data): int
{
    qrEnsureEventArchiveColumns($pdo);
    $eventId = isset($data['event_id']) ? (int)$data['event_id'] : 0;
    if ($eventId > 0) {
        $chk = $pdo->prepare("SELECT event_id FROM events WHERE event_id = :id AND org_id = :org AND archived_at IS NULL LIMIT 1");
        $chk->execute([':id' => $eventId, ':org' => $orgId]);
        if (!$chk->fetch()) {
            throw new QrAttendanceValidationException('Event not found for this organization.');
        }
        return $eventId;
    }

    $eventName = trim((string)($data['event_name'] ?? $data['event'] ?? ''));
    if ($eventName === '') {
        throw new QrAttendanceValidationException('event_id or event_name is required.');
    }
    $existing = qrFindEventIdByName($pdo, $orgId, $eventName);
    if ($existing) return $existing;

    return qrSaveEvent($pdo, $orgId, $userId, ['event_name' => $eventName]);
}

function qrListAttendance(PDO $pdo, int $orgId, array $filters = []): array
{
    $where = ["e.org_id = :org"];
    $params = [':org' => $orgId];

    $eventId = isset($filters['event_id']) ? (int)$filters['event_id'] : 0;
    if ($eventId > 0) {
        $where[] = "ar.event_id = :event_id";
        $params[':event_id'] = $eventId;
    }

    $eventName = trim((string)($filters['event_name'] ?? $filters['event'] ?? ''));
    if ($eventName !== '') {
        $where[] = "e.event_name = :event_name";
        $params[':event_name'] = $eventName;
    }

    $section = trim((string)($filters['section'] ?? ''));
    if ($section !== '') {
        $where[] = "ar.section = :section";
        $params[':section'] = $section;
    }

    $dateFrom = trim((string)($filters['date_from'] ?? ''));
    if ($dateFrom !== '') {
        $where[] = "COALESCE(DATE(ar.time_in), DATE(ar.created_at)) >= :date_from";
        $params[':date_from'] = $dateFrom;
    }
    $dateTo = trim((string)($filters['date_to'] ?? ''));
    if ($dateTo !== '') {
        $where[] = "COALESCE(DATE(ar.time_in), DATE(ar.created_at)) <= :date_to";
        $params[':date_to'] = $dateTo;
    }

    $q = trim((string)($filters['q'] ?? ''));
    if ($q !== '') {
        $where[] = "(ar.student_number LIKE :q_sn OR ar.student_name LIKE :q_name OR ar.section LIKE :q_section OR e.event_name LIKE :q_event)";
        $qLike = '%' . $q . '%';
        $params[':q_sn'] = $qLike;
        $params[':q_name'] = $qLike;
        $params[':q_section'] = $qLike;
        $params[':q_event'] = $qLike;
    }

    $limit = isset($filters['limit']) ? (int)$filters['limit'] : 2000;
    if ($limit <= 0 || $limit > 10000) $limit = 2000;

    $sql = "
        SELECT ar.record_id,
               ar.event_id,
               ar.user_id,
               ar.student_number,
               ar.student_name,
               ar.section,
               ar.time_in,
               ar.time_out,
               ar.created_at,
               ar.updated_at,
               e.event_name,
               COALESCE(DATE(ar.time_in), DATE(ar.created_at)) AS attendance_date,
               CASE
                   WHEN ar.time_in IS NULL AND ar.time_out IS NULL THEN 'registered'
                   WHEN ar.time_in IS NOT NULL AND ar.time_out IS NULL THEN 'checked_in'
                   WHEN ar.time_out IS NOT NULL THEN 'checked_out'
                   ELSE 'pending'
               END AS attendance_status
        FROM attendance_records ar
        JOIN events e ON e.event_id = ar.event_id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY COALESCE(ar.time_out, ar.time_in, ar.created_at) DESC
        LIMIT " . (int)$limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['record_id'] = (int)$row['record_id'];
        $row['event_id'] = (int)$row['event_id'];
        $row['user_id'] = $row['user_id'] !== null ? (int)$row['user_id'] : null;
    }
    return $rows;
}

function qrFindUserIdByStudentNumber(PDO $pdo, string $studentNumber): ?int
{
    $sn = trim($studentNumber);
    if ($sn === '') return null;
    $stmt = $pdo->prepare(
        "SELECT user_id
         FROM users
         WHERE student_number = :sn
           AND account_type = 'student'
           AND is_active = 1
         LIMIT 1"
    );
    $stmt->execute([':sn' => $sn]);
    $row = $stmt->fetch();
    return $row ? (int)$row['user_id'] : null;
}

function qrCheckIn(PDO $pdo, int $orgId, int $userId, array $data): array
{
    $eventId = qrResolveEventId($pdo, $orgId, $userId, $data);
    $studentNumber = trim((string)($data['student_number'] ?? $data['studentId'] ?? ''));
    $studentName = trim((string)($data['student_name'] ?? $data['studentName'] ?? ''));
    $section = trim((string)($data['section'] ?? ''));
    if ($studentNumber === '') {
        if ($studentName === '') throw new QrAttendanceValidationException('Name is required.');
        $studentNumber = 'GUEST-' . bin2hex(random_bytes(9));
    }

    $times = qrAttendanceCaptureTimes($pdo, $data);
    $now = $times['captured'];

    if ($studentName === '') {
        $lookup = $pdo->prepare(
            "SELECT CONCAT(first_name, ' ', last_name) AS full_name
             FROM users
             WHERE student_number = :sn
               AND account_type = 'student'
             LIMIT 1"
        );
        $lookup->execute([':sn' => $studentNumber]);
        $row = $lookup->fetch();
        if ($row && !empty($row['full_name'])) $studentName = trim((string)$row['full_name']);
    }
    if ($studentName === '') $studentName = $studentNumber;

    $studentUserId = qrFindUserIdByStudentNumber($pdo, $studentNumber);

    // The event/student unique key arbitrates simultaneous scans and races
    // with pre-registration. Only the first check-in may set time_in.
    $ins = $pdo->prepare(
        "INSERT INTO attendance_records
            (event_id, user_id, student_number, student_name, section, time_in, check_in_received_at)
         VALUES
            (:event_id, :user_id, :student_number, :student_name, :section, :time_in, :received_at)"
    );
    $insertParams = [
        ':event_id' => $eventId,
        ':user_id' => $studentUserId,
        ':student_number' => $studentNumber,
        ':student_name' => $studentName,
        ':section' => $section !== '' ? $section : null,
        ':time_in' => $now->format('Y-m-d H:i:s'),
        ':received_at' => $times['received']->format('Y-m-d H:i:s'),
    ];
    try {
        $ins->execute($insertParams);
        $claimed = true;
    } catch (PDOException $e) {
        if ((int)($e->errorInfo[1] ?? 0) !== 1062) throw $e;
        // Claim a pre-registration once. A repeat scan matches no rows, so
        // the updated_at trigger cannot make it look like a new check-in.
        $claim = $pdo->prepare(
            "UPDATE attendance_records
             SET time_in = :time_in, check_in_received_at = :received_at
             WHERE event_id = :event_id AND student_number = :student_number
               AND time_in IS NULL"
        );
        $claim->execute([
            ':time_in' => $insertParams[':time_in'],
            ':received_at' => $insertParams[':received_at'],
            ':event_id' => $eventId,
            ':student_number' => $studentNumber,
        ]);
        $claimed = $claim->rowCount() === 1;
    }
    $check = $pdo->prepare(
        "SELECT record_id, time_in, time_out FROM attendance_records
         WHERE event_id = :event_id AND student_number = :student_number LIMIT 1 FOR UPDATE"
    );
    $check->execute([':event_id' => $eventId, ':student_number' => $studentNumber]);
    $existing = $check->fetch();
    if (!$existing) throw new RuntimeException('Attendance record could not be found after check-in.');

    return [
        'record_id' => (int)$existing['record_id'],
        'event_id' => $eventId,
        'already_checked_in' => !$claimed,
        'already_checked_out' => !empty($existing['time_out']),
        'time_in' => $claimed ? $now->format(DateTimeInterface::ATOM) : $existing['time_in'],
        'time_out' => $existing['time_out'],
    ];
}

function qrCheckOut(PDO $pdo, int $orgId, int $userId, array $data): array
{
    qrEnsureEventArchiveColumns($pdo);
    $recordId = isset($data['record_id']) ? (int)$data['record_id'] : 0;

    $times = qrAttendanceCaptureTimes($pdo, $data);
    $now = $times['captured'];
    $today = $now->format('Y-m-d');

    if ($recordId > 0) {
        $sel = $pdo->prepare(
            "SELECT ar.record_id, ar.event_id, ar.time_in, ar.time_out
             FROM attendance_records ar
             JOIN events e ON e.event_id = ar.event_id
             WHERE ar.record_id = :record_id
               AND e.org_id = :org
               AND e.archived_at IS NULL
             LIMIT 1"
        );
        $sel->execute([':record_id' => $recordId, ':org' => $orgId]);
        $row = $sel->fetch();
    } else {
        $eventId = qrResolveEventId($pdo, $orgId, $userId, $data);
        $studentNumber = trim((string)($data['student_number'] ?? $data['studentId'] ?? ''));
        $date = trim((string)($data['date'] ?? $today));
        if ($studentNumber === '') {
            throw new QrAttendanceValidationException('student_number is required when record_id is missing.');
        }
        $sel = $pdo->prepare(
            "SELECT record_id, event_id, time_in, time_out
             FROM attendance_records
             WHERE event_id = :event_id
               AND student_number = :student_number
               AND DATE(time_in) = :date_ref
             ORDER BY record_id DESC
             LIMIT 1"
        );
        $sel->execute([
            ':event_id' => $eventId,
            ':student_number' => $studentNumber,
            ':date_ref' => $date,
        ]);
        $row = $sel->fetch();
    }

    if (!$row) {
        throw new QrAttendanceValidationException('Attendance record not found.');
    }
    if (!empty($row['time_out'])) {
        return [
            'record_id' => (int)$row['record_id'],
            'event_id' => (int)$row['event_id'],
            'already_checked_out' => true,
            'time_out' => $row['time_out'],
        ];
    }

    $upd = $pdo->prepare(
        "UPDATE attendance_records ar
         JOIN events e ON e.event_id = ar.event_id
         SET ar.time_out = :time_out,
             ar.check_out_received_at = :received_at
         WHERE ar.record_id = :record_id
           AND e.org_id = :org
           AND e.archived_at IS NULL
           AND ar.time_out IS NULL"
    );
    $upd->execute([
        ':time_out' => $now->format('Y-m-d H:i:s'),
        ':received_at' => $times['received']->format('Y-m-d H:i:s'),
        ':record_id' => (int)$row['record_id'],
        ':org' => $orgId,
    ]);
    if ($upd->rowCount() === 0) {
        $current = $pdo->prepare(
            "SELECT time_out FROM attendance_records WHERE record_id = :record_id LIMIT 1 FOR UPDATE"
        );
        $current->execute([':record_id' => (int)$row['record_id']]);
        $latest = $current->fetch();
        if ($latest && !empty($latest['time_out'])) {
            return [
                'record_id' => (int)$row['record_id'],
                'event_id' => (int)$row['event_id'],
                'already_checked_out' => true,
                'time_out' => $latest['time_out'],
            ];
        }
        throw new QrAttendanceValidationException('Attendance could not be checked out. Refresh and try again.');
    }

    return [
        'record_id' => (int)$row['record_id'],
        'event_id' => (int)$row['event_id'],
        'already_checked_out' => false,
        'time_out' => $now->format(DateTimeInterface::ATOM),
    ];
}

function qrUpdateAttendanceTime(PDO $pdo, int $orgId, array $data): array
{
    qrEnsureEventArchiveColumns($pdo);
    $recordId = isset($data['record_id']) ? (int)$data['record_id'] : 0;
    $field = trim((string)($data['field'] ?? ''));
    $value = trim((string)($data['value'] ?? ''));

    if ($recordId <= 0) {
        throw new QrAttendanceValidationException('record_id is required.');
    }
    if (!in_array($field, ['time_in', 'time_out'], true)) {
        throw new QrAttendanceValidationException('field must be time_in or time_out.');
    }

    $sel = $pdo->prepare(
        "SELECT ar.record_id
         FROM attendance_records ar
         JOIN events e ON e.event_id = ar.event_id
         WHERE ar.record_id = :record_id
           AND e.org_id = :org
           AND e.archived_at IS NULL
         LIMIT 1"
    );
    $sel->execute([':record_id' => $recordId, ':org' => $orgId]);
    if (!$sel->fetch()) {
        throw new QrAttendanceValidationException('Attendance record not found for this organization.');
    }

    if ($value === '') {
        $tz = new DateTimeZone('Asia/Manila');
        $value = (new DateTimeImmutable('now', $tz))->format('Y-m-d H:i:s');
    } else {
        $ts = strtotime($value);
        if ($ts === false) {
            throw new QrAttendanceValidationException('Invalid datetime value.');
        }
        $value = date('Y-m-d H:i:s', $ts);
    }

    $sql = "UPDATE attendance_records SET {$field} = :value WHERE record_id = :record_id";
    $upd = $pdo->prepare($sql);
    $upd->execute([':value' => $value, ':record_id' => $recordId]);

    return [
        'record_id' => $recordId,
        'field' => $field,
        'value' => $value,
    ];
}

function qrListStudents(PDO $pdo, int $orgId, array $filters = []): array
{
    $hasYearSection = qrAttendanceColumnExists($pdo, 'users', 'year_section');
    $sectionExpr = $hasYearSection ? "COALESCE(u.year_section, '')" : "''";

    $where = ["u.account_type = 'student'", "u.is_active = 1"];
    $params = [':membership_org' => $orgId, ':attendance_org' => $orgId];

    $q = trim((string)($filters['q'] ?? ''));
    if ($q !== '') {
        $where[] = "(u.student_number LIKE :q_sn OR CONCAT(u.first_name, ' ', u.last_name) LIKE :q_name OR u.email LIKE :q_email)";
        $qLike = '%' . $q . '%';
        $params[':q_sn'] = $qLike;
        $params[':q_name'] = $qLike;
        $params[':q_email'] = $qLike;
    }

    $sql = "
        SELECT DISTINCT u.user_id,
               u.student_number,
               CONCAT(u.first_name, ' ', u.last_name) AS student_name,
               {$sectionExpr} AS section,
               u.email,
               u.created_at,
               u.updated_at
        FROM users u
        LEFT JOIN organization_members om
               ON om.user_id = u.user_id
              AND om.org_id = :membership_org
              AND om.is_active = 1
        WHERE " . implode(' AND ', $where) . "
          AND (
                om.membership_id IS NOT NULL
                OR EXISTS (
                    SELECT 1
                    FROM attendance_records ar
                    JOIN events e ON e.event_id = ar.event_id
                    WHERE e.org_id = :attendance_org
                      AND ar.student_number = u.student_number
                )
          )
        ORDER BY u.student_number ASC, u.user_id ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['user_id'] = (int)$row['user_id'];
    }
    return $rows;
}

function qrGenerateStudentEmail(PDO $pdo, string $studentNumber): string
{
    $baseLocal = preg_replace('/[^a-zA-Z0-9._-]/', '', strtolower($studentNumber));
    if ($baseLocal === '') $baseLocal = 'student';
    $domain = 'qr.local';
    $candidate = $baseLocal . '@' . $domain;
    $suffix = 0;

    while (true) {
        $check = $pdo->prepare("SELECT 1 FROM users WHERE email = :email LIMIT 1");
        $check->execute([':email' => $candidate]);
        if (!$check->fetch()) return $candidate;
        $suffix++;
        $candidate = $baseLocal . $suffix . '@' . $domain;
    }
}

function qrSaveStudent(PDO $pdo, int $orgId, array $data): int
{
    $userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;
    $studentNumber = trim((string)($data['student_number'] ?? $data['studentId'] ?? ''));
    $studentName = trim((string)($data['student_name'] ?? $data['studentName'] ?? ''));
    $section = trim((string)($data['section'] ?? ''));
    $email = trim((string)($data['email'] ?? ''));
    $password = (string)($data['password'] ?? '12345678');

    if ($studentNumber === '') {
        throw new QrAttendanceValidationException('student_number is required.');
    }
    if ($studentName === '') {
        throw new QrAttendanceValidationException('student_name is required.');
    }
    if (strlen($password) < 8) {
        throw new QrAttendanceValidationException('Password must be at least 8 characters.');
    }

    [$firstName, $lastName] = qrSplitFullName($studentName);
    if ($email === '') {
        $email = qrGenerateStudentEmail($pdo, $studentNumber);
    }

    $hasYearSection = qrAttendanceColumnExists($pdo, 'users', 'year_section');

    if ($userId > 0) {
        $sel = $pdo->prepare(
            "SELECT user_id
             FROM users
             WHERE user_id = :uid
               AND account_type = 'student'
             LIMIT 1"
        );
        $sel->execute([':uid' => $userId]);
        if (!$sel->fetch()) {
            throw new QrAttendanceValidationException('Student user not found.');
        }

        if ($hasYearSection) {
            $upd = $pdo->prepare(
                "UPDATE users
                 SET student_number = :student_number,
                     first_name = :first_name,
                     last_name = :last_name,
                     email = :email,
                     year_section = :section
                 WHERE user_id = :uid"
            );
            $upd->execute([
                ':student_number' => $studentNumber,
                ':first_name' => $firstName,
                ':last_name' => $lastName,
                ':email' => $email,
                ':section' => $section !== '' ? $section : null,
                ':uid' => $userId,
            ]);
        } else {
            $upd = $pdo->prepare(
                "UPDATE users
                 SET student_number = :student_number,
                     first_name = :first_name,
                     last_name = :last_name,
                     email = :email
                 WHERE user_id = :uid"
            );
            $upd->execute([
                ':student_number' => $studentNumber,
                ':first_name' => $firstName,
                ':last_name' => $lastName,
                ':email' => $email,
                ':uid' => $userId,
            ]);
        }
        return $userId;
    }

    $dup = $pdo->prepare("SELECT user_id FROM users WHERE student_number = :sn LIMIT 1");
    $dup->execute([':sn' => $studentNumber]);
    $dupRow = $dup->fetch();
    if ($dupRow) {
        return qrSaveStudent($pdo, $orgId, [
            ...$data,
            'user_id' => (int)$dupRow['user_id'],
            'email' => $email,
            'student_number' => $studentNumber,
            'student_name' => $studentName,
            'section' => $section,
        ]);
    }

    if ($hasYearSection) {
        $ins = $pdo->prepare(
            "INSERT INTO users
                (student_number, first_name, last_name, email, password_hash, account_type, year_section, is_active)
             VALUES
                (:student_number, :first_name, :last_name, :email, :password_hash, 'student', :section, 1)"
        );
        $ins->execute([
            ':student_number' => $studentNumber,
            ':first_name' => $firstName,
            ':last_name' => $lastName,
            ':email' => $email,
            ':password_hash' => password_hash($password, PASSWORD_BCRYPT),
            ':section' => $section !== '' ? $section : null,
        ]);
    } else {
        $ins = $pdo->prepare(
            "INSERT INTO users
                (student_number, first_name, last_name, email, password_hash, account_type, is_active)
             VALUES
                (:student_number, :first_name, :last_name, :email, :password_hash, 'student', 1)"
        );
        $ins->execute([
            ':student_number' => $studentNumber,
            ':first_name' => $firstName,
            ':last_name' => $lastName,
            ':email' => $email,
            ':password_hash' => password_hash($password, PASSWORD_BCRYPT),
        ]);
    }
    return (int)$pdo->lastInsertId();
}

function qrDeleteStudent(PDO $pdo, int $orgId, array $data): void
{
    $userId = isset($data['user_id']) ? (int)$data['user_id'] : 0;
    $studentNumber = trim((string)($data['student_number'] ?? ''));

    if ($userId <= 0 && $studentNumber === '') {
        throw new QrAttendanceValidationException('user_id or student_number is required.');
    }

    if ($userId > 0) {
        $upd = $pdo->prepare(
            "UPDATE users
             SET is_active = 0
             WHERE user_id = :uid
               AND account_type = 'student'"
        );
        $upd->execute([':uid' => $userId]);
    } else {
        $upd = $pdo->prepare(
            "UPDATE users
             SET is_active = 0
             WHERE student_number = :sn
               AND account_type = 'student'"
        );
        $upd->execute([':sn' => $studentNumber]);
    }

    if ($upd->rowCount() === 0) {
        throw new QrAttendanceValidationException('Student user not found.');
    }
}
