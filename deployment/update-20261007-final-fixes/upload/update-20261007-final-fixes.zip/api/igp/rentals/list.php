<?php
require_once __DIR__ . '/../../../includes/auth.php';
require_once __DIR__ . '/../../../includes/igp.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');
apiGuard();

try {
    $ctx = igpRequireOfficerOrgContext();
    $filters = [
        'status' => trim((string)($_GET['status'] ?? '')),
        'payment_status' => trim((string)($_GET['payment_status'] ?? '')),
        'date_from' => trim((string)($_GET['date_from'] ?? '')),
        'date_to' => trim((string)($_GET['date_to'] ?? '')),
        'q' => trim((string)($_GET['q'] ?? '')),
    ];
    $items = igpGetRentals(getPdo(), $ctx['org_id'], $filters);
    jsonOk(['items' => $items]);
} catch (IgpAuthorizationException $e) {
    jsonError($e->getMessage(), 403);
} catch (IgpConflictException $e) {
    jsonError($e->getMessage(), 409, ['code' => 'RENTAL_CONFLICT']);
} catch (PDOException $e) {
    if (igpIsConcurrencyError($e)) {
        jsonError('Another rental operation is in progress. Refresh and try again.', 409, ['code' => 'RENTAL_CONFLICT']);
    }
    error_log('[api/igp/rentals/list] ' . $e->getMessage());
    jsonError('A database error occurred. Please try again.', 500);
} catch (Throwable $e) {
    jsonError($e->getMessage(), 400);
}
