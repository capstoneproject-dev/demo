// Only use this for new passwords, never login or existing-account verification.
function passwordMeetsPolicy(password) {
  return Array.from(password).length >= 12
    && /[A-Z]/.test(password)
    && /[0-9]/.test(password);
}

/* =====================
   AUTH + UI STATE (LocalStorage simulation of SQL flow)
   ===================== */
const AUTH_DB_KEY = 'naapAuthDB_v1';
const AUTH_SESSION_KEY = 'naapAuthSession';
const LEGACY_STUDENT_PROFILE_KEY = 'naapStudentProfile';
const ACCOUNTS_APPROVED_KEY = 'AccountsSystem_studentAccounts';
const PENDING_REQUESTS_KEY = 'AccountsSystem_pendingRequests';
const OSA_INVITATION_SESSION_KEY = 'naapOsaInvitationToken';
let activeOsaInvitationToken = '';

const COURSE_INSTITUTE_MAP = {
  BSAIT: 'Institute of Computer Studies',
  BSAIS: 'Institute of Computer Studies',
  BSAET: 'Institute of Engineering Technology',
  BSAT: 'Institute of Engineering Technology',
  BSAMT: 'Institute of Engineering Technology',
  BSAEE: 'Institute of Engineering Technology',
  'BAT-AET': 'Institute of Engineering Technology',
  AVCOMM: 'Institute of Liberal Arts and Sciences',
  AVLOG: 'Institute of Liberal Arts and Sciences',
  AVSSM: 'Institute of Liberal Arts and Sciences',
  AVTOUR: 'Institute of Liberal Arts and Sciences'
};

function normalizeCourse(code) {
  return String(code || '').trim().toUpperCase();
}

function setupPasswordVisibilityToggles() {
  document.querySelectorAll('.password-toggle').forEach((toggle) => {
    toggle.addEventListener('click', () => {
      const input = toggle.closest('.password-field')?.querySelector('input');
      if (!input) return;

      const isVisible = input.type === 'text';
      input.type = isVisible ? 'password' : 'text';
      toggle.setAttribute('aria-pressed', String(!isVisible));
      toggle.setAttribute('aria-label', isVisible ? 'Show password' : 'Hide password');
      toggle.title = isVisible ? 'Show password' : 'Hide password';
    });
  });
}

function normalizeOrgName(name) {
  const raw = String(name || '').trim();
  const upper = raw.toUpperCase();
  const aliases = {
    SSC: 'Supreme Student Council',
    'SUPREME STUDENT COUNCIL': 'Supreme Student Council',
    AERONAUTICA: 'AERONAUTICA',
    SAGE: "Scholars' Aviation Guild of Excellence",
    PSG: "Scholars' Aviation Guild of Excellence",
    "SCHOLARS' AVIATION GUILD OF EXCELLENCE": "Scholars' Aviation Guild of Excellence",
    "SCHOLAR'S GUILD": "Scholars' Aviation Guild of Excellence",
    'SCHOLARS GUILD': "Scholars' Aviation Guild of Excellence",
    AMT: 'AMTSO',
    AET: 'AETSO'
  };
  return aliases[upper] || raw;
}

function safeParse(json, fallback) {
  try {
    const parsed = JSON.parse(json);
    return parsed && typeof parsed === 'object' ? parsed : fallback;
  } catch (_err) {
    return fallback;
  }
}

function nowIso() {
  return new Date().toISOString();
}

function nextId(rows, keyName) {
  if (!Array.isArray(rows) || rows.length === 0) return 1;
  return rows.reduce((maxId, row) => Math.max(maxId, Number(row[keyName]) || 0), 0) + 1;
}

function splitName(fullName) {
  const clean = String(fullName || '').trim().replace(/\s+/g, ' ');
  if (!clean) return { first_name: '', last_name: '' };
  const parts = clean.split(' ');
  if (parts.length === 1) return { first_name: parts[0], last_name: '-' };
  return {
    first_name: parts.slice(0, -1).join(' '),
    last_name: parts[parts.length - 1]
  };
}

function seedAuthDb() {
  const organizations = [
    { org_id: 1, org_name: 'AISERS', org_code: 'AISERS', status: 'active' },
    { org_id: 2, org_name: 'ELITECH', org_code: 'ELITECH', status: 'active' },
    { org_id: 3, org_name: 'CYC', org_code: 'CYC', status: 'active' },
    { org_id: 4, org_name: 'Supreme Student Council', org_code: 'SSC', status: 'active' },
    { org_id: 5, org_name: 'ILASSO', org_code: 'ILASSO', status: 'active' },
    { org_id: 6, org_name: 'AERO-ATSO', org_code: 'AERO-ATSO', status: 'active' },
    { org_id: 7, org_name: 'AETSO', org_code: 'AETSO', status: 'active' },
    { org_id: 8, org_name: 'AMTSO', org_code: 'AMTSO', status: 'active' },
    { org_id: 9, org_name: 'RCYC', org_code: 'RCYC', status: 'active' },
    { org_id: 10, org_name: "Scholars' Aviation Guild of Excellence", org_code: 'SAGE', status: 'active' },
    { org_id: 11, org_name: 'AERONAUTICA', org_code: 'AERONAUTICA', status: 'active' }
  ];

  const orgRoles = [];
  let roleId = 1;
  organizations.forEach((org) => {
    orgRoles.push({ role_id: roleId++, org_id: org.org_id, role_name: 'officer', can_access_org_dashboard: 1, is_active: 1 });
    orgRoles.push({ role_id: roleId++, org_id: org.org_id, role_name: 'auditor', can_access_org_dashboard: 1, is_active: 1 });
    orgRoles.push({ role_id: roleId++, org_id: org.org_id, role_name: 'member', can_access_org_dashboard: 0, is_active: 1 });
  });

  const academicPrograms = [
    'BSAIT', 'BSAIS', 'BSAET', 'BSAT', 'BSAMT', 'BSAeE', 'BAT-AET', 'AvComm', 'Avlog', 'AvSSm', 'AvTour'
  ].map((code, idx) => ({
    program_id: idx + 1,
    program_code: code,
    institute_name: COURSE_INSTITUTE_MAP[normalizeCourse(code)] || 'Institute of Computer Studies',
    is_active: 1
  }));

  const orgByCode = Object.fromEntries(organizations.map((org) => [org.org_code.toUpperCase(), org.org_id]));

  const programOrgMappings = [
    ['BSAIT', 'ELITECH'],
    ['BSAIS', 'AISERS'],
    ['BSAET', 'AETSO'],
    ['BSAT', 'AERO-ATSO'],
    ['BSAMT', 'AMTSO'],
    ['BSAEE', 'AETSO'],
    ['BAT-AET', 'AETSO'],
    ['AVCOMM', 'ILASSO'],
    ['AVLOG', 'ILASSO'],
    ['AVSSM', 'ILASSO'],
    ['AVTOUR', 'ILASSO']
  ].map(([programCode, orgCode], idx) => {
    const program = academicPrograms.find((p) => normalizeCourse(p.program_code) === programCode);
    return {
      mapping_id: idx + 1,
      program_id: program ? program.program_id : null,
      org_id: orgByCode[orgCode],
      is_active: 1
    };
  }).filter((m) => m.program_id && m.org_id);

  const users = [
    {
      user_id: 1,
      student_number: '2023-10001',
      employee_number: null,
      email: 'aisers.officer1@school.edu',
      password_hash: '12345678',
      first_name: 'Aira',
      last_name: 'Santos',
      account_type: 'student',
      has_unpaid_debt: 0,
      is_active: 1,
      created_at: nowIso(),
      updated_at: nowIso()
    },
    {
      user_id: 2,
      student_number: null,
      employee_number: 'OSA-0001',
      email: 'osa.staff@school.edu',
      password_hash: '12345678',
      first_name: 'Olivia',
      last_name: 'Garcia',
      account_type: 'osa_staff',
      has_unpaid_debt: 0,
      is_active: 1,
      created_at: nowIso(),
      updated_at: nowIso()
    }
  ];

  const studentProfiles = [
    { user_id: 1, program_id: 2, section: 'IS-1A', created_at: nowIso(), updated_at: nowIso() }
  ];

  const officerRoleAisers = orgRoles.find((r) => r.org_id === 1 && r.role_name === 'officer');
  const auditorRoles = orgRoles.filter((r) => r.role_name === 'auditor');

  const organizationMembers = [
    {
      membership_id: 1,
      user_id: 1,
      org_id: 1,
      role_id: officerRoleAisers ? officerRoleAisers.role_id : 1,
      position_title: 'President',
      joined_at: '2025-08-01',
      is_active: 1
    }
  ];

  if (users[1] && auditorRoles.length) {
    auditorRoles.forEach((role, idx) => {
      organizationMembers.push({
        membership_id: organizationMembers.length + 1 + idx,
        user_id: users[1].user_id,
        org_id: role.org_id,
        role_id: role.role_id,
        position_title: null,
        joined_at: '2025-08-01',
        is_active: 1
      });
    });
  }

  return {
    users,
    organizations,
    org_roles: orgRoles,
    organization_members: organizationMembers,
    academic_programs: academicPrograms,
    student_profiles: studentProfiles,
    program_org_mappings: programOrgMappings
  };
}

function getAuthDb() {
  const stored = safeParse(localStorage.getItem(AUTH_DB_KEY), null);
  if (stored && Array.isArray(stored.users) && Array.isArray(stored.organizations)) {
    return stored;
  }
  const seeded = seedAuthDb();
  localStorage.setItem(AUTH_DB_KEY, JSON.stringify(seeded));
  return seeded;
}

function saveAuthDb(db) {
  localStorage.setItem(AUTH_DB_KEY, JSON.stringify(db));
}

function findProgramByCode(db, courseCode) {
  const normalized = normalizeCourse(courseCode);
  return db.academic_programs.find((program) => normalizeCourse(program.program_code) === normalized) || null;
}

function findOrCreateProgram(db, courseCode) {
  const existing = findProgramByCode(db, courseCode);
  if (existing) return existing;

  const normalized = normalizeCourse(courseCode);
  const created = {
    program_id: nextId(db.academic_programs, 'program_id'),
    program_code: normalized,
    institute_name: COURSE_INSTITUTE_MAP[normalized] || 'Institute of Computer Studies',
    is_active: 1,
    created_at: nowIso(),
    updated_at: nowIso()
  };
  db.academic_programs.push(created);
  return created;
}

function findOrCreateOrganization(db, orgName) {
  const normalized = normalizeOrgName(orgName);
  const existing = db.organizations.find((org) => normalizeOrgName(org.org_name) === normalized);
  if (existing) return existing;

  const compactCode = normalized.toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 20) || `ORG${Date.now()}`;
  const candidateCodes = new Set(db.organizations.map((org) => String(org.org_code || '').toUpperCase()));
  let finalCode = compactCode;
  let seq = 2;
  while (candidateCodes.has(finalCode.toUpperCase())) {
    finalCode = `${compactCode}-${seq++}`.slice(0, 20);
  }

  const created = {
    org_id: nextId(db.organizations, 'org_id'),
    org_name: normalized,
    org_code: finalCode,
    status: 'active',
    created_at: nowIso(),
    updated_at: nowIso()
  };
  db.organizations.push(created);

  ['officer', 'auditor', 'member'].forEach((roleName) => {
    db.org_roles.push({
      role_id: nextId(db.org_roles, 'role_id'),
      org_id: created.org_id,
      role_name: roleName,
      can_access_org_dashboard: roleName === 'member' ? 0 : 1,
      is_active: 1,
      created_at: nowIso(),
      updated_at: nowIso()
    });
  });

  return created;
}

function findRole(db, orgId, roleName) {
  return db.org_roles.find((role) => role.org_id === orgId && String(role.role_name).toLowerCase() === String(roleName).toLowerCase() && Number(role.is_active) === 1) || null;
}

function addMembershipIfMissing(db, userId, orgId, roleId) {
  const exists = db.organization_members.find((membership) => membership.user_id === userId && membership.org_id === orgId);
  if (exists) {
    exists.role_id = roleId;
    if (!Object.prototype.hasOwnProperty.call(exists, 'position_title')) {
      exists.position_title = null;
    }
    exists.is_active = 1;
    return exists;
  }

  const created = {
    membership_id: nextId(db.organization_members, 'membership_id'),
    user_id: userId,
    org_id: orgId,
    role_id: roleId,
    position_title: null,
    joined_at: new Date().toISOString().slice(0, 10),
    is_active: 1,
    created_at: nowIso(),
    updated_at: nowIso()
  };
  db.organization_members.push(created);
  return created;
}

function getMappedOrgForProgram(db, programId) {
  const mapping = db.program_org_mappings.find((m) => m.program_id === programId && Number(m.is_active) === 1);
  if (!mapping) return null;
  return db.organizations.find((org) => org.org_id === mapping.org_id) || null;
}

function getStudentProfileByUserId(db, userId) {
  return db.student_profiles.find((profile) => profile.user_id === userId) || null;
}

function getProgramById(db, programId) {
  return db.academic_programs.find((program) => program.program_id === programId) || null;
}

function getOfficerMemberships(db, userId) {
  return db.organization_members
    .filter((membership) => membership.user_id === userId && Number(membership.is_active) === 1)
    .map((membership) => {
      const role = db.org_roles.find((r) => r.role_id === membership.role_id && Number(r.is_active) === 1);
      const org = db.organizations.find((o) => o.org_id === membership.org_id && String(o.status).toLowerCase() !== 'suspended');
      if (!role || !org || Number(role.can_access_org_dashboard) !== 1) return null;
      return {
        membership_id: membership.membership_id,
        org_id: org.org_id,
        org_name: org.org_name,
        role_name: role.role_name,
        position_title: membership.position_title || role.role_name,
        role_id: role.role_id
      };
    })
    .filter(Boolean);
}

function upsertStudentProfile(db, userId, programId, section) {
  const current = db.student_profiles.find((profile) => profile.user_id === userId);
  if (current) {
    current.program_id = programId;
    current.section = section;
    current.updated_at = nowIso();
    return current;
  }

  const created = {
    user_id: userId,
    program_id: programId,
    section,
    created_at: nowIso(),
    updated_at: nowIso()
  };
  db.student_profiles.push(created);
  return created;
}

function setSession(sessionData) {
  localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(sessionData));
}

function createBaseSession(db, user) {
  return {
    user_id: user.user_id,
    account_type: user.account_type,
    display_name: `${user.first_name} ${user.last_name}`.trim(),
    email: user.email,
    student_number: user.student_number || null,
    employee_number: user.employee_number || null,
    authenticated_at: nowIso(),
    officer_memberships: getOfficerMemberships(db, user.user_id)
  };
}

function setLegacyStudentProfile(db, user, fallbackOrgName) {
  const studentProfile = getStudentProfileByUserId(db, user.user_id);
  const program = studentProfile ? getProgramById(db, studentProfile.program_id) : null;
  const orgName = fallbackOrgName || (program ? (getMappedOrgForProgram(db, program.program_id) || {}).org_name : null) || 'Supreme Student Council';

  localStorage.setItem(LEGACY_STUDENT_PROFILE_KEY, JSON.stringify({
    studentNumber: user.student_number || '',
    fullName: `${user.first_name} ${user.last_name}`.trim(),
    course: program ? program.program_code : '',
    section: studentProfile ? studentProfile.section || '' : '',
    email: user.email,
    organization: orgName
  }));
}

function redirectToStudent(db, user, preferredOrgName) {
  const session = {
    ...createBaseSession(db, user),
    login_role: 'student',
    active_org_name: preferredOrgName || null,
    active_org_id: preferredOrgName
      ? (db.organizations.find((org) => normalizeOrgName(org.org_name) === normalizeOrgName(preferredOrgName)) || {}).org_id || null
      : null
  };
  setSession(session);
  setLegacyStudentProfile(db, user, preferredOrgName || null);
  window.location.href = '../student/';
}

function redirectToOfficer(db, user, selectedOrgId) {
  const session = createBaseSession(db, user);
  const selectedMembership = session.officer_memberships.find((membership) => membership.org_id === Number(selectedOrgId));
  if (!selectedMembership) {
    alert('Please select a valid officer organization.');
    return;
  }

  setSession({
    ...session,
    login_role: 'org',
    active_org_id: selectedMembership.org_id,
    active_org_name: selectedMembership.org_name,
    active_role_name: selectedMembership.role_name
  });

  window.location.href = '../officer/';
}

function redirectToOsa(db, user) {
  const session = {
    ...createBaseSession(db, user),
    login_role: 'osa',
    active_org_id: null,
    active_org_name: 'Office of Student Affairs',
    active_role_name: 'osa_staff'
  };
  setSession(session);
  window.location.href = '../osa/';
}

function createUser(db, payload) {
  const userId = nextId(db.users, 'user_id');
  const user = {
    user_id: userId,
    student_number: payload.student_number || null,
    employee_number: payload.employee_number || null,
    email: payload.email,
    password_hash: payload.password,
    first_name: payload.first_name,
    last_name: payload.last_name,
    account_type: payload.account_type,
    has_unpaid_debt: 0,
    is_active: 1,
    last_login_at: null,
    created_at: nowIso(),
    updated_at: nowIso()
  };
  db.users.push(user);
  return user;
}

function findUserByIdentifier(db, identifier) {
  const id = String(identifier || '').trim().toLowerCase();
  if (!id) return null;
  return db.users.find((user) =>
    String(user.email || '').toLowerCase() === id ||
    String(user.student_number || '').toLowerCase() === id ||
    String(user.employee_number || '').toLowerCase() === id
  ) || null;
}

function isDuplicateIdentity(db, email, studentNumber, employeeNumber) {
  const emailLower = String(email || '').trim().toLowerCase();
  const studentLower = String(studentNumber || '').trim().toLowerCase();
  const employeeLower = String(employeeNumber || '').trim().toLowerCase();

  return db.users.some((user) => {
    const emailMatch = emailLower && String(user.email || '').toLowerCase() === emailLower;
    const studentMatch = studentLower && String(user.student_number || '').toLowerCase() === studentLower;
    const employeeMatch = employeeLower && String(user.employee_number || '').toLowerCase() === employeeLower;
    return emailMatch || studentMatch || employeeMatch;
  });
}

function parseCourseSection(sectionText) {
  const value = String(sectionText || '').trim();
  if (!value) return { course: '', section: '' };
  const parts = value.split(/\s+/);
  if (parts.length === 1) return { course: normalizeCourse(parts[0]), section: '' };
  return {
    course: normalizeCourse(parts[0]),
    section: parts.slice(1).join(' ')
  };
}

function getPendingRequests() {
  return safeParse(localStorage.getItem(PENDING_REQUESTS_KEY), []);
}

function savePendingRequests(requests) {
  localStorage.setItem(PENDING_REQUESTS_KEY, JSON.stringify(requests));
}

function getApprovedAccounts() {
  return safeParse(localStorage.getItem(ACCOUNTS_APPROVED_KEY), []);
}

function requestId() {
  return `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * submitPendingRegistration – async, calls PHP REST endpoint.
 * Returns { ok: boolean, message: string }
 */
async function submitPendingRegistration(payload) {
  try {
    const res = await fetch('../api/accounts/requests/submit.php', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentId: payload.studentId || '',
        employeeNumber: payload.employeeNumber || '',
        name: payload.name || '',
        email: payload.email || '',
        phone: payload.phone || '',
        password: payload.password || '',
        course: payload.course || '',
        yearSection: payload.yearSection || '',
        section: payload.section || '',
        requestedRole: payload.requestedRole || 'student',
        requestedOrg: payload.requestedOrg || '',
        requestedPosition: payload.requestedPosition || '',
        verification_token: payload.verificationToken || ''
      })
    });
    const json = await res.json();
    if (json.ok) return { ok: true };
    return { ok: false, message: json.error || 'Registration failed.' };
  } catch (err) {
    return { ok: false, message: 'Network error: ' + err.message };
  }
}

function trySyncAuthorizedStudentFromAccounts(db, identifier, password) {
  const normalizedIdentifier = String(identifier || '').trim().toLowerCase();
  const approvedStudents = safeParse(localStorage.getItem(ACCOUNTS_APPROVED_KEY), []);
  if (!Array.isArray(approvedStudents) || !normalizedIdentifier) return null;

  const approved = approvedStudents.find((item) => {
    const matchId = String(item.studentId || '').trim().toLowerCase() === normalizedIdentifier;
    const matchEmail = String(item.email || '').trim().toLowerCase() === normalizedIdentifier;
    return (matchId || matchEmail) && String(item.password || '') === String(password || '');
  });

  if (!approved) return null;

  let user = db.users.find((u) =>
    String(u.student_number || '').toLowerCase() === String(approved.studentId || '').toLowerCase() ||
    String(u.email || '').toLowerCase() === String(approved.email || '').toLowerCase()
  );

  const parsedName = splitName(approved.studentName || approved.name || approved.studentId || 'Student User');
  if (!user) {
    user = createUser(db, {
      student_number: approved.studentId || null,
      employee_number: null,
      email: approved.email || `${String(approved.studentId || 'student').toLowerCase()}@student.local`,
      password: approved.password,
      first_name: parsedName.first_name,
      last_name: parsedName.last_name,
      account_type: 'student'
    });
  } else {
    user.first_name = parsedName.first_name || user.first_name;
    user.last_name = parsedName.last_name || user.last_name;
    user.password_hash = approved.password || user.password_hash;
    user.student_number = approved.studentId || user.student_number;
    user.email = approved.email || user.email;
    user.account_type = 'student';
    user.updated_at = nowIso();
  }

  const courseCode = approved.programCode || approved.course || '';
  const parsedSection = parseCourseSection(approved.section || `${courseCode} ${approved.yearSection || ''}`.trim());
  if (parsedSection.course) {
    const program = findOrCreateProgram(db, parsedSection.course);
    upsertStudentProfile(db, user.user_id, program.program_id, parsedSection.section || '');
    const mappedOrg = getMappedOrgForProgram(db, program.program_id);
    if (mappedOrg) {
      const memberRole = findRole(db, mappedOrg.org_id, 'member');
      if (memberRole) addMembershipIfMissing(db, user.user_id, mappedOrg.org_id, memberRole.role_id);
    }
  }

  if (String(approved.requestedRole || '').toLowerCase() === 'org_officer' && approved.requestedOrg) {
    const selectedOrg = findOrCreateOrganization(db, approved.requestedOrg);
    const officerRole = findRole(db, selectedOrg.org_id, 'officer');
    if (officerRole) {
      const membership = addMembershipIfMissing(db, user.user_id, selectedOrg.org_id, officerRole.role_id);
      membership.position_title = approved.requestedPosition || membership.position_title || null;
      membership.updated_at = nowIso();
    }
  }

  return user;
}

/* =====================
   MAIN SLIDER LOGIC (LEFT <-> RIGHT)
   ===================== */
const container = document.getElementById('container');
const signUpBtn = document.getElementById('signUp');
const signInBtn = document.getElementById('signIn');
const overlayLeft = document.querySelector('.overlay-left');
const overlayRight = document.querySelector('.overlay-right');

if (overlayRight && overlayLeft) {
  overlayRight.classList.add('active');
  overlayLeft.classList.remove('active');
}

function toggleSlide() {
  if (!container || !overlayLeft || !overlayRight) return;
  container.classList.toggle('right-panel-active');
  if (container.classList.contains('right-panel-active')) {
    overlayRight.classList.remove('active');
    overlayLeft.classList.add('active');
  } else {
    overlayLeft.classList.remove('active');
    overlayRight.classList.add('active');
  }
}

if (signUpBtn) signUpBtn.addEventListener('click', toggleSlide);
if (signInBtn) signInBtn.addEventListener('click', toggleSlide);

/* =====================
   LEFT PANEL INTERNAL TOGGLE (LOGIN <-> FORGOT)
   ===================== */
const signInContainer = document.getElementById('signInContainer');
const forgotOtpState = {
  challengeToken: '',
  verificationToken: '',
  sentToEmail: '',
  sentToStudentNumber: '',
  verified: false,
  isSubmitting: false,
  resendTimer: null
};
const registrationOtpState = {
  challengeToken: '',
  verificationToken: '',
  pendingAction: null,
  pendingEmail: '',
  pendingIdentifier: '',
  pendingPurpose: '',
  pendingLabel: '',
  invitationToken: '',
  pendingStudentName: '',
  pendingCurrentPassword: '',
  isSubmitting: false,
  isSending: false,
  resendTimer: null
};

function getForgotOtpInputs() {
  return Array.from(document.querySelectorAll('#forgotOtpInputs .otp-char'));
}

function setLoginStatusMessage(message, isSuccess) {
  const status = document.getElementById('loginStatusMessage');
  if (!status) return;
  status.textContent = message || '';
  status.classList.toggle('hidden', !message);
  status.classList.toggle('success', !!isSuccess);
}

function setForgotFormFeedback(message, isSuccess) {
  const feedback = document.getElementById('forgotFormFeedback');
  if (!feedback) return;
  feedback.textContent = message || '';
  feedback.classList.toggle('hidden', !message);
  feedback.classList.toggle('success', !!isSuccess);
}

function clearForgotOtpFeedback() {
  const feedback = document.getElementById('forgotOtpFeedback');
  if (!feedback) return;
  feedback.textContent = '';
  feedback.classList.remove('success');
}

function setForgotOtpFeedback(message, isSuccess) {
  const feedback = document.getElementById('forgotOtpFeedback');
  if (!feedback) return;
  feedback.textContent = message || '';
  feedback.classList.toggle('success', !!isSuccess);
}

function resetForgotOtpInputs() {
  getForgotOtpInputs().forEach((input) => { input.value = ''; });
}

function focusForgotOtpInput(index) {
  const inputs = getForgotOtpInputs();
  if (!inputs[index]) return;
  inputs[index].focus();
  inputs[index].select();
}

function getForgotOtpValue() {
  return getForgotOtpInputs().map((input) => String(input.value || '').trim().toUpperCase()).join('');
}

function startOtpResendCountdown(button, seconds, state) {
  if (state.resendTimer) clearInterval(state.resendTimer);
  let remaining = Math.max(0, Number(seconds) || 0);
  const render = () => {
    if (!button) return;
    button.disabled = remaining > 0;
    button.textContent = remaining > 0 ? `RESEND OTP (${remaining}s)` : 'RESEND OTP';
  };
  render();
  state.resendTimer = setInterval(() => {
    remaining -= 1;
    render();
    if (remaining <= 0) {
      clearInterval(state.resendTimer);
      state.resendTimer = null;
    }
  }, 1000);
}

function revealForgotOtpSection() {
  const section = document.getElementById('forgotOtpSection');
  if (section) section.classList.remove('hidden');
}

function resetForgotPasswordFlow(keepFields) {
  forgotOtpState.challengeToken = '';
  forgotOtpState.verificationToken = '';
  forgotOtpState.sentToEmail = '';
  forgotOtpState.sentToStudentNumber = '';
  forgotOtpState.verified = false;
  forgotOtpState.isSubmitting = false;
  if (forgotOtpState.resendTimer) clearInterval(forgotOtpState.resendTimer);
  forgotOtpState.resendTimer = null;

  const section = document.getElementById('forgotOtpSection');
  if (section) section.classList.add('hidden');

  const status = document.getElementById('forgotOtpStatus');
  if (status) status.textContent = 'A 6-digit OTP was sent to your email.';

  const resendBtn = document.getElementById('forgotResendOtpBtn');
  const verifyBtn = document.getElementById('forgotVerifyOtpBtn');
  if (resendBtn) {
    resendBtn.disabled = false;
    resendBtn.textContent = 'RESEND OTP';
  }
  if (verifyBtn) verifyBtn.disabled = false;

  clearForgotOtpFeedback();
  resetForgotOtpInputs();
  setForgotFormFeedback('', false);

  if (!keepFields) {
    const studentInput = document.getElementById('forgotStudentNumber');
    const emailInput = document.getElementById('forgotEmail');
    const newPasswordInput = document.getElementById('forgotNewPassword');
    const confirmPasswordInput = document.getElementById('forgotConfirmPassword');
    if (studentInput) studentInput.value = '';
    if (emailInput) emailInput.value = '';
    if (newPasswordInput) newPasswordInput.value = '';
    if (confirmPasswordInput) confirmPasswordInput.value = '';
  }
}

async function sendForgotOtp() {
  const studentInput = document.getElementById('forgotStudentNumber');
  const emailInput = document.getElementById('forgotEmail');
  const newPasswordInput = document.getElementById('forgotNewPassword');
  const confirmPasswordInput = document.getElementById('forgotConfirmPassword');
  const status = document.getElementById('forgotOtpStatus');
  const sendBtn = document.getElementById('forgotSendOtpBtn');
  const resendBtn = document.getElementById('forgotResendOtpBtn');

  const studentNumber = String((studentInput && studentInput.value) || '').trim();
  const email = String((emailInput && emailInput.value) || '').trim();
  const newPassword = String((newPasswordInput && newPasswordInput.value) || '');
  const confirmPassword = String((confirmPasswordInput && confirmPasswordInput.value) || '');

  if (!studentNumber || !email) {
    setForgotFormFeedback('Enter your student number and email address.', false);
    return;
  }
  if (!newPassword || !confirmPassword) {
    setForgotFormFeedback('Enter your new password and confirm it before sending the OTP.', false);
    return;
  }
  if (!passwordMeetsPolicy(newPassword)) {
    setForgotFormFeedback('Password must be at least 12 characters and contain an uppercase letter and a number.', false);
    return;
  }
  if (newPassword !== confirmPassword) {
    setForgotFormFeedback('New passwords do not match.', false);
    return;
  }

  if (sendBtn) sendBtn.disabled = true;
  if (resendBtn) resendBtn.disabled = true;
  setForgotFormFeedback('Sending verification code...', true);
  try {
    const response = await fetch('../api/auth/otp/send.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ purpose: 'password_reset', email, identifier: studentNumber })
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || 'Could not send the verification code.');

    forgotOtpState.challengeToken = data.challenge_token;
    forgotOtpState.verificationToken = '';
    forgotOtpState.sentToEmail = email;
    forgotOtpState.sentToStudentNumber = studentNumber;
    forgotOtpState.verified = false;
    revealForgotOtpSection();
    resetForgotOtpInputs();
    clearForgotOtpFeedback();
    setForgotFormFeedback(data.message || 'Verification code requested.', true);
    setLoginStatusMessage('', false);
    if (status) status.textContent = `Enter the 6-digit code sent to ${email}.`;
    startOtpResendCountdown(resendBtn, data.resend_after, forgotOtpState);
    focusForgotOtpInput(0);
  } catch (error) {
    setForgotFormFeedback(error.message || 'Could not send the verification code.', false);
    if (resendBtn) resendBtn.disabled = false;
  } finally {
    if (sendBtn) sendBtn.disabled = false;
  }
}

async function verifyForgotOtp() {
  const enteredOtp = getForgotOtpValue();
  const newPasswordInput = document.getElementById('forgotNewPassword');
  const confirmPasswordInput = document.getElementById('forgotConfirmPassword');
  const newPassword = String((newPasswordInput && newPasswordInput.value) || '');
  const confirmPassword = String((confirmPasswordInput && confirmPasswordInput.value) || '');

  if (forgotOtpState.isSubmitting) return;

  if (!forgotOtpState.challengeToken) {
    setForgotOtpFeedback('Send an OTP first.', false);
    return;
  }
  if (enteredOtp.length !== 6) {
    setForgotOtpFeedback('Enter the complete 6-digit OTP.', false);
    return;
  }
  if (!newPassword || !confirmPassword) {
    setForgotOtpFeedback('Enter your new password and confirm it.', false);
    return;
  }
  if (!passwordMeetsPolicy(newPassword)) {
    setForgotOtpFeedback('Password must be at least 12 characters and contain an uppercase letter and a number.', false);
    return;
  }
  if (newPassword !== confirmPassword) {
    setForgotOtpFeedback('New passwords do not match.', false);
    return;
  }

  const studentNumber = String(forgotOtpState.sentToStudentNumber || '').trim();
  const email = String(forgotOtpState.sentToEmail || '').trim();
  const verifyBtn = document.getElementById('forgotVerifyOtpBtn');
  forgotOtpState.isSubmitting = true;
  if (verifyBtn) verifyBtn.disabled = true;

  try {
    if (!forgotOtpState.verificationToken) {
      const verificationResponse = await fetch('../api/auth/otp/verify.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ challenge_token: forgotOtpState.challengeToken, otp: enteredOtp })
      });
      const verificationData = await verificationResponse.json();
      if (!verificationResponse.ok || !verificationData.ok) {
        throw new Error(verificationData.error || 'Invalid or expired verification code.');
      }
      forgotOtpState.verificationToken = verificationData.verification_token;
    }

    const response = await fetch('../api/auth/forgot-password-reset.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        student_number: studentNumber,
        email,
        verification_token: forgotOtpState.verificationToken,
        new_password: newPassword
      })
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || 'Could not reset the password.');

    forgotOtpState.verified = true;
    setForgotOtpFeedback('OTP verified.', true);

    setLoginStatusMessage('Password has been reset. Please log in again with your new password.', true);
  } catch (error) {
    console.error('[verifyForgotOtp] error:', error);
    setForgotOtpFeedback(error.message || 'Could not verify the code.', false);
    forgotOtpState.isSubmitting = false;
    if (verifyBtn) verifyBtn.disabled = false;
    return;
  }

  setTimeout(() => {
    if (signInContainer && signInContainer.classList.contains('forgot-mode')) {
      signInContainer.classList.remove('forgot-mode');
    }
    const loginIdentifier = document.getElementById('loginIdentifier');
    const loginPassword = document.getElementById('loginPassword');
    if (loginIdentifier) loginIdentifier.value = studentNumber;
    if (loginPassword) loginPassword.value = newPassword;
    resetForgotPasswordFlow(false);
    if (loginPassword) loginPassword.focus();
  }, 700);
}

function setupForgotOtpInputs() {
  const inputs = getForgotOtpInputs();
  if (inputs.length === 0) return;

  inputs.forEach((input, index) => {
    input.addEventListener('input', (event) => {
      const clean = String(event.target.value || '').replace(/\D/g, '').slice(-1);
      event.target.value = clean;
      clearForgotOtpFeedback();
      if (clean && index < inputs.length - 1) focusForgotOtpInput(index + 1);
    });

    input.addEventListener('keydown', (event) => {
      if (event.key === 'Backspace' && !input.value && index > 0) {
        focusForgotOtpInput(index - 1);
        return;
      }
      if (event.key === 'ArrowLeft' && index > 0) {
        event.preventDefault();
        focusForgotOtpInput(index - 1);
      }
      if (event.key === 'ArrowRight' && index < inputs.length - 1) {
        event.preventDefault();
        focusForgotOtpInput(index + 1);
      }
    });

    input.addEventListener('paste', (event) => {
      event.preventDefault();
      const pasted = (event.clipboardData || window.clipboardData).getData('text');
      const chars = String(pasted || '').replace(/\D/g, '').slice(0, 6).split('');
      if (chars.length === 0) return;
      inputs.forEach((field, idx) => { field.value = chars[idx] || ''; });
      clearForgotOtpFeedback();
      focusForgotOtpInput(Math.min(chars.length, 6) - 1);
    });
  });
}

function setupForgotPasswordFlow() {
  const sendBtn = document.getElementById('forgotSendOtpBtn');
  const verifyBtn = document.getElementById('forgotVerifyOtpBtn');
  const resendBtn = document.getElementById('forgotResendOtpBtn');
  const form = document.getElementById('forgotPasswordForm');

  setupForgotOtpInputs();
  resetForgotPasswordFlow(false);

  if (sendBtn) sendBtn.addEventListener('click', sendForgotOtp);
  if (verifyBtn) verifyBtn.addEventListener('click', verifyForgotOtp);
  if (resendBtn) resendBtn.addEventListener('click', sendForgotOtp);
  if (form) form.addEventListener('submit', (event) => event.preventDefault());
}

function toggleForgot() {
  if (!signInContainer) return;
  signInContainer.classList.toggle('forgot-mode');
  if (!signInContainer.classList.contains('forgot-mode')) {
    resetForgotPasswordFlow(false);
    return;
  }
  setLoginStatusMessage('', false);
  clearForgotOtpFeedback();
  const studentInput = document.getElementById('forgotStudentNumber');
  if (studentInput) studentInput.focus();
}

function getRegistrationOtpInputs() {
  return Array.from(document.querySelectorAll('#registrationOtpInputs .otp-char'));
}

function clearRegistrationOtpFeedback() {
  const feedback = document.getElementById('registrationOtpFeedback');
  if (!feedback) return;
  feedback.textContent = '';
  feedback.classList.remove('success');
}

function setRegistrationOtpFeedback(message, isSuccess) {
  const feedback = document.getElementById('registrationOtpFeedback');
  if (!feedback) return;
  feedback.textContent = message || '';
  feedback.classList.toggle('success', !!isSuccess);
}

function resetRegistrationOtpInputs() {
  getRegistrationOtpInputs().forEach((input) => { input.value = ''; });
}

function focusRegistrationOtpInput(index) {
  const inputs = getRegistrationOtpInputs();
  if (!inputs[index]) return;
  inputs[index].focus();
  inputs[index].select();
}

function getRegistrationOtpValue() {
  return getRegistrationOtpInputs().map((input) => String(input.value || '').trim().toUpperCase()).join('');
}

function openRegistrationOtpModal() {
  const modal = document.getElementById('registrationOtpModal');
  if (modal) modal.classList.add('open');
}

function closeRegistrationOtpModal() {
  const modal = document.getElementById('registrationOtpModal');
  if (modal) modal.classList.remove('open');
  registrationOtpState.pendingAction = null;
  registrationOtpState.pendingEmail = '';
  registrationOtpState.pendingIdentifier = '';
  registrationOtpState.pendingPurpose = '';
  registrationOtpState.pendingLabel = '';
  registrationOtpState.invitationToken = '';
  registrationOtpState.pendingStudentName = '';
  registrationOtpState.pendingCurrentPassword = '';
  registrationOtpState.challengeToken = '';
  registrationOtpState.verificationToken = '';
  registrationOtpState.isSubmitting = false;
  registrationOtpState.isSending = false;
  if (registrationOtpState.resendTimer) clearInterval(registrationOtpState.resendTimer);
  registrationOtpState.resendTimer = null;
  const status = document.getElementById('registrationOtpStatus');
  if (status) status.textContent = 'Enter the 6-digit OTP to continue registration.';
  const resendBtn = document.getElementById('registrationOtpResendBtn');
  const verifyBtn = document.getElementById('registrationOtpVerifyBtn');
  if (resendBtn) {
    resendBtn.disabled = false;
    resendBtn.textContent = 'RESEND OTP';
  }
  if (verifyBtn) verifyBtn.disabled = false;
  clearRegistrationOtpFeedback();
  resetRegistrationOtpInputs();
}

async function sendRegistrationOtp() {
  if (!registrationOtpState.pendingAction || registrationOtpState.isSending) return;
  registrationOtpState.isSending = true;
  registrationOtpState.isSubmitting = false;
  const status = document.getElementById('registrationOtpStatus');
  const resendBtn = document.getElementById('registrationOtpResendBtn');
  const verifyBtn = document.getElementById('registrationOtpVerifyBtn');
  if (status) status.textContent = 'Sending verification code...';
  if (resendBtn) resendBtn.disabled = true;
  if (verifyBtn) verifyBtn.disabled = true;
  clearRegistrationOtpFeedback();
  resetRegistrationOtpInputs();
  openRegistrationOtpModal();
  try {
    const response = await fetch('../api/auth/otp/send.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        purpose: registrationOtpState.pendingPurpose,
        email: registrationOtpState.pendingEmail,
        identifier: registrationOtpState.pendingIdentifier,
        invitation_token: registrationOtpState.invitationToken || undefined,
        student_name: registrationOtpState.pendingStudentName || undefined,
        current_password: registrationOtpState.pendingCurrentPassword || undefined
      })
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || 'Could not send the verification code.');

    registrationOtpState.challengeToken = data.challenge_token;
    registrationOtpState.verificationToken = '';
    if (status) status.textContent = `Enter the 6-digit code sent to ${registrationOtpState.pendingEmail}.`;
    setRegistrationOtpFeedback(data.message || 'Verification code requested.', true);
    startOtpResendCountdown(resendBtn, data.resend_after, registrationOtpState);
    focusRegistrationOtpInput(0);
  } catch (error) {
    if (status) status.textContent = `Verify ${registrationOtpState.pendingLabel} registration.`;
    setRegistrationOtpFeedback(error.message || 'Could not send the verification code.', false);
    if (resendBtn) resendBtn.disabled = false;
  } finally {
    registrationOtpState.isSending = false;
    if (verifyBtn) verifyBtn.disabled = false;
  }
}

async function verifyRegistrationOtp() {
  const enteredOtp = getRegistrationOtpValue();
  if (!registrationOtpState.challengeToken) {
    setRegistrationOtpFeedback('Send an OTP first.', false);
    return;
  }
  if (enteredOtp.length !== 6) {
    setRegistrationOtpFeedback('Enter the complete 6-digit OTP.', false);
    return;
  }
  if (!registrationOtpState.pendingAction || registrationOtpState.isSubmitting) return;

  registrationOtpState.isSubmitting = true;
  setRegistrationOtpFeedback('Verifying OTP...', true);
  const verifyBtn = document.getElementById('registrationOtpVerifyBtn');
  const resendBtn = document.getElementById('registrationOtpResendBtn');
  if (verifyBtn) verifyBtn.disabled = true;
  if (resendBtn) resendBtn.disabled = true;

  try {
    if (!registrationOtpState.verificationToken) {
      const response = await fetch('../api/auth/otp/verify.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ challenge_token: registrationOtpState.challengeToken, otp: enteredOtp })
      });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || 'Invalid or expired verification code.');
      registrationOtpState.verificationToken = data.verification_token;
    }
    await registrationOtpState.pendingAction(registrationOtpState.verificationToken);
    closeRegistrationOtpModal();
  } catch (error) {
    registrationOtpState.isSubmitting = false;
    if (verifyBtn) verifyBtn.disabled = false;
    if (resendBtn && !registrationOtpState.resendTimer) resendBtn.disabled = false;
    console.error('[verifyRegistrationOtp] error:', error);
    setRegistrationOtpFeedback(error.message || 'The registration could not be completed.', false);
  }
}

function setupRegistrationOtpInputs() {
  const inputs = getRegistrationOtpInputs();
  if (inputs.length === 0) return;

  inputs.forEach((input, index) => {
    input.addEventListener('input', (event) => {
      const clean = String(event.target.value || '').replace(/\D/g, '').slice(-1);
      event.target.value = clean;
      clearRegistrationOtpFeedback();
      if (clean && index < inputs.length - 1) focusRegistrationOtpInput(index + 1);
    });

    input.addEventListener('keydown', (event) => {
      if (event.key === 'Backspace' && !input.value && index > 0) {
        focusRegistrationOtpInput(index - 1);
        return;
      }
      if (event.key === 'ArrowLeft' && index > 0) {
        event.preventDefault();
        focusRegistrationOtpInput(index - 1);
      }
      if (event.key === 'ArrowRight' && index < inputs.length - 1) {
        event.preventDefault();
        focusRegistrationOtpInput(index + 1);
      }
    });

    input.addEventListener('paste', (event) => {
      event.preventDefault();
      const pasted = (event.clipboardData || window.clipboardData).getData('text');
      const chars = String(pasted || '').replace(/\D/g, '').slice(0, 6).split('');
      if (chars.length === 0) return;
      inputs.forEach((field, idx) => { field.value = chars[idx] || ''; });
      clearRegistrationOtpFeedback();
      focusRegistrationOtpInput(Math.min(chars.length, 6) - 1);
    });
  });
}

function startRegistrationOtpFlow(label, email, identifier, purpose, action, invitationToken = '', studentName = '', currentPassword = '') {
  registrationOtpState.pendingAction = action;
  registrationOtpState.pendingEmail = String(email || '').trim();
  registrationOtpState.pendingIdentifier = String(identifier || '').trim();
  registrationOtpState.pendingPurpose = purpose;
  registrationOtpState.pendingLabel = label;
  registrationOtpState.invitationToken = invitationToken;
  registrationOtpState.pendingStudentName = String(studentName || '').trim();
  registrationOtpState.pendingCurrentPassword = String(currentPassword || '');
  sendRegistrationOtp();
}

function setupRegistrationOtpFlow() {
  const modal = document.getElementById('registrationOtpModal');
  const verifyBtn = document.getElementById('registrationOtpVerifyBtn');
  const resendBtn = document.getElementById('registrationOtpResendBtn');

  setupRegistrationOtpInputs();

  if (modal) {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeRegistrationOtpModal();
    });
  }
  if (verifyBtn) verifyBtn.addEventListener('click', verifyRegistrationOtp);
  if (resendBtn) resendBtn.addEventListener('click', sendRegistrationOtp);
}

/* =====================
   REGISTER TABS LOGIC
   ===================== */
function switchTab(type) {
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach((btn) => btn.classList.remove('active'));

  const registrationContent = document.getElementById('registration-content');
  if (registrationContent) registrationContent.classList.toggle('org-tab-active', type === 'org');
  const registrationPanel = document.querySelector('.sign-up-container');
  if (registrationPanel) registrationPanel.scrollTop = 0;

  const activeFormId = type === 'student' ? 'form-student' : type === 'osa' ? 'form-osa' : 'form-org';

  const clicked = Array.from(tabs).find((btn) => {
    const txt = String(btn.textContent || '').trim().toLowerCase();
    return (type === 'org' && txt.includes('organization')) || txt === type;
  });
  if (clicked) clicked.classList.add('active');

  document.querySelectorAll('.reg-fields').forEach((form) => form.classList.remove('active'));
  const activeForm = document.getElementById(activeFormId);
  if (activeForm) activeForm.classList.add('active');
}

/* =====================
   ORGANIZATION MODAL LOGIC
   ===================== */
const orgModal = document.getElementById('orgModal');
const orgInput = document.getElementById('org-input');
const orgPositionInput = document.getElementById('org-position-input');
const ORGANIZATION_POSITIONS = {
  'AERO-ATSO': [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Assistant Secretary',
    'Treasurer', 'Auditor', 'Public Information Officer', 'Business Manager (Aero)', 'Business Manager (AT)',
    'Peace Officer (Aero)', 'Peace Officer (AT)', '4th Year Representative (AT)',
    '4th Year Representative (Aero)', '3rd Year Representative (AT)', '3rd Year Representative (Aero)',
    '2nd Year Representative (AT)', '2nd Year Representative (Aero)', '1st Year Representative (AT)',
    '1st Year Representative (Aero)'
  ],
  'SUPREME STUDENT COUNCIL': [
    'President', 'Vice President Internal', 'Vice President External', 'Senator For Finance Committee',
    'Senator For Secretariat Committee', 'Senator For Public Relations Committee',
    'Senator For Student Rights and Welfare Committee'
  ],
  AETSO: [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Treasurer', 'Auditor',
    'Public Information Officer', 'Business Manager (Male)', 'Business Manager (Female)',
    'Peace Officer (Male)', 'Peace Officer (Female)', '4th Year Representative', '3rd Year Representative',
    '2nd Year Representative', '1st Year Representative'
  ],
  AISERS: [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Assistant Secretary',
    'Treasurer', 'Auditor', 'Public Information Officer', 'Business Manager', 'Peace Officer', 'Peace Officer',
    '4th Year Representative', '3rd Year Representative', '2nd Year Representative', '1st Year Representative'
  ],
  AMTSO: [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Treasurer', 'Auditor',
    'Public Information Officer', 'Peace Officer (Female)', 'Peace Officer (Male)', '4th Year Representative',
    '2nd Year Representative', '1st Year Representative'
  ],
  ELITECH: [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Treasurer', 'Auditor',
    'Public Information Officer', 'Business Manager', 'Peace Officer (Female)', 'Peace Officer (Male)',
    '4th Year Representative', '3rd Year Representative', '2nd Year Representative', '1st Year Representative'
  ],
  ILASSO: [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Assistant Secretary',
    'Treasurer', 'Assistant Treasurer', 'Auditor', 'Public Information Officer', 'Business Manager',
    'Peace Officer', 'Peace Officer', '4th Year Representative', '3rd Year Representative',
    '2nd Year Representative', '1st Year Representative'
  ],
  CYC: [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Assistant Secretary',
    'Treasurer', 'Assistant Treasurer', 'Auditor', 'Business Manager', 'Public Information Officer',
    'Peace Officer', 'Creative Head', 'Creative Committee/Officer', 'Creative Committee/Officer',
    'Director for Membership & Publicity', 'Director for Ways and Means',
    'Director for Events and Services', 'Director for Sports & Logistics',
    'Director for Ecumenical and Spiritual Care', 'Director for Extension and Community Engagement'
  ],
  "SCHOLARS' AVIATION GUILD OF EXCELLENCE": [
    'President', 'Vice President for Internal Affairs', 'Vice President for External Affairs',
    'Vice President for Finance', 'Vice President for Audit and Logistics',
    'Vice President for Documentation', 'Vice President for Public Relations',
    'Vice President for Community Development', 'Vice President for Education and Research'
  ],
  AERONAUTICA: [
    'Editor-in-Chief', 'Associate Editor', 'Managing Editor', 'Feature Editor', 'News Editor', 'Sports Editor',
    'Opinion Editor', 'Chief Photojournalist', 'Graphics and Layout Editor', 'Literary Editor',
    'Social Media Manager', 'Copy Reader', 'Staff Writer', 'Photojournalist'
  ],
  RCYC: [
    'President', 'Vice President Internal', 'Vice President External', 'Secretary', 'Assistant Secretary',
    'Treasurer', 'Assistant Treasurer', 'Auditor', 'Public Relations Officer', 'Membership and Recruitment',
    'Communication and Advocacy', 'Resource Generation', 'Council Management and Development',
    'Awards and Recognition', 'Learnings and Innovation', 'Blood Programs', 'Creatives',
    'Publication (Creatives)', 'Documentation (Creatives)', 'External Relations', 'Crisis Management'
  ]
};
const orgStudentNumberInput = document.getElementById('org-student-number-input');
const orgRegistrationDetails = document.getElementById('org-registration-details');
const orgLookupMessage = document.getElementById('org-student-lookup-message');
const orgStudentRegistrationFields = document.getElementById('org-student-registration-fields');
const orgAdviserRegistrationFields = document.getElementById('org-adviser-registration-fields');
const orgLockedFieldIds = [
  'org-name-input',
  'org-course-input',
  'org-section-input',
  'org-email-input',
  'org-phone-input'
];
let verifiedOrgStudentNumber = '';
let activeOrgLookupToken = 0;

function openOrgModal() {
  if (orgModal) orgModal.classList.add('open');
}

function closeOrgModal() {
  if (orgModal) orgModal.classList.remove('open');
}

function selectOrg(orgName) {
  const normalizedOrgName = normalizeOrgName(orgName);
  const organizationChanged = orgInput && orgInput.value !== normalizedOrgName;
  if (orgInput) orgInput.value = normalizedOrgName;
  setRegistrationFieldInvalid(orgInput, false);
  if (organizationChanged && orgPositionInput) {
    orgPositionInput.value = '';
    updateOrganizationRegistrationMode();
  }
  if (orgPositionInput) {
    orgPositionInput.placeholder = 'Select Position';
    orgPositionInput.classList.remove('org-select-trigger-disabled');
    orgPositionInput.setAttribute('aria-disabled', 'false');
  }
  closeOrgModal();
}

if (orgModal) {
  orgModal.addEventListener('click', (e) => {
    if (e.target === orgModal) closeOrgModal();
  });
}

const positionModal = document.getElementById('positionModal');
const positionList = document.getElementById('position-list');
const customPositionEditor = document.getElementById('custom-position-editor');
const customPositionInput = document.getElementById('custom-position-input');
const customPositionFeedback = document.getElementById('custom-position-feedback');
const predefinedPositionTitles = new Set([
  ...Object.values(ORGANIZATION_POSITIONS).flat(),
  'Organization Adviser'
]);

function getSelectedOrganizationPositions() {
  const organizationKey = normalizeOrgName(orgInput?.value || '').toUpperCase();
  return ORGANIZATION_POSITIONS[organizationKey] || [];
}

function appendPositionOption(positionTitle) {
  if (!positionList) return;
  const option = document.createElement('button');
  option.type = 'button';
  option.className = 'org-item position-other-btn';
  option.textContent = positionTitle;
  option.addEventListener('click', () => selectPosition(positionTitle));
  positionList.appendChild(option);
}

function renderOrganizationPositions() {
  if (!positionList) return;
  positionList.replaceChildren();
  getSelectedOrganizationPositions().forEach(appendPositionOption);
  appendPositionOption('Organization Adviser');

  const otherButton = document.createElement('button');
  otherButton.type = 'button';
  otherButton.className = 'org-item position-other-btn';
  otherButton.textContent = 'Others';
  otherButton.addEventListener('click', openCustomPositionEditor);
  positionList.appendChild(otherButton);
}

function resetCustomPositionEditor() {
  if (positionList) positionList.hidden = false;
  if (customPositionEditor) customPositionEditor.hidden = true;
  if (customPositionFeedback) customPositionFeedback.textContent = '';
}

function openPositionModal() {
  if (!String(orgInput?.value || '').trim()) {
    alert('Select an organization before selecting a position.');
    openOrgModal();
    return;
  }
  renderOrganizationPositions();
  resetCustomPositionEditor();
  if (positionModal) positionModal.classList.add('open');
}

function closePositionModal() {
  if (positionModal) positionModal.classList.remove('open');
  resetCustomPositionEditor();
}

function selectPosition(positionTitle) {
  if (orgPositionInput) {
    orgPositionInput.value = String(positionTitle || '').trim();
    setRegistrationFieldInvalid(orgPositionInput, false);
  }
  updateOrganizationRegistrationMode();
  closePositionModal();
}

function isOrganizationAdviserRegistration() {
  return String(orgPositionInput?.value || '').trim().toLowerCase() === 'organization adviser';
}

function updateOrganizationRegistrationMode() {
  const adviserMode = isOrganizationAdviserRegistration();
  if (orgStudentRegistrationFields) orgStudentRegistrationFields.hidden = adviserMode;
  if (orgAdviserRegistrationFields) orgAdviserRegistrationFields.hidden = !adviserMode;
  if (adviserMode) {
    verifiedOrgStudentNumber = '';
    setOrgRegistrationVisibility(false);
  }
}

function openCustomPositionEditor() {
  if (positionList) positionList.hidden = true;
  if (customPositionEditor) customPositionEditor.hidden = false;
  if (customPositionFeedback) customPositionFeedback.textContent = '';
  if (customPositionInput) {
    const currentTitle = String(orgPositionInput?.value || '').trim();
    customPositionInput.value = currentTitle && !predefinedPositionTitles.has(currentTitle) ? currentTitle : '';
    window.setTimeout(() => customPositionInput.focus(), 0);
  }
}

function cancelCustomPositionEditor() {
  resetCustomPositionEditor();
}

function confirmCustomPosition() {
  const title = String(customPositionInput?.value || '').replace(/\s+/g, ' ').trim();
  if (title.length < 2) {
    if (customPositionFeedback) customPositionFeedback.textContent = 'Enter a position title with at least 2 characters.';
    if (customPositionInput) customPositionInput.focus();
    return;
  }
  if (title.length > 120) {
    if (customPositionFeedback) customPositionFeedback.textContent = 'Position title must be 120 characters or fewer.';
    return;
  }
  if (/[\u0000-\u001F\u007F]/.test(title)) {
    if (customPositionFeedback) customPositionFeedback.textContent = 'Position title contains unsupported characters.';
    return;
  }
  selectPosition(title);
}

if (customPositionInput) {
  customPositionInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      confirmCustomPosition();
    } else if (event.key === 'Escape') {
      event.preventDefault();
      cancelCustomPositionEditor();
    }
  });
}

if (positionModal) {
  positionModal.addEventListener('click', (e) => {
    if (e.target === positionModal) closePositionModal();
  });
}

/* =====================
   COURSE MODAL LOGIC
   ===================== */
const courseModal = document.getElementById('courseModal');
let activeCourseInputId = null;

function openCourseModal(inputId) {
  activeCourseInputId = inputId;
  if (courseModal) courseModal.classList.add('open');
}

function closeCourseModal() {
  if (courseModal) courseModal.classList.remove('open');
  activeCourseInputId = null;
}

function selectCourse(courseName) {
  if (activeCourseInputId) {
    const input = document.getElementById(activeCourseInputId);
    if (input) {
      input.value = courseName;
      setRegistrationFieldInvalid(input, false);
    }
  }
  closeCourseModal();
}

if (courseModal) {
  courseModal.addEventListener('click', (e) => {
    if (e.target === courseModal) closeCourseModal();
  });
}

function normalizePhoneInput(value) {
  const digitsOnly = String(value || '').replace(/\D/g, '');
  let localDigits = digitsOnly;
  if (localDigits.startsWith('63')) localDigits = localDigits.slice(2);
  if (localDigits.startsWith('0')) localDigits = localDigits.slice(1);
  localDigits = localDigits.slice(0, 10);
  return `+63 ${localDigits}`;
}

function isValidPhoneInput(value) {
  return /^\+63\s\d{10}$/.test(String(value || '').trim());
}

function setupPhoneInput(inputId) {
  const input = document.getElementById(inputId);
  if (!input) return;

  const applyNormalized = () => {
    input.value = normalizePhoneInput(input.value);
  };

  applyNormalized();
  input.addEventListener('input', applyNormalized);
  input.addEventListener('focus', () => {
    if (!input.value || input.value === '+63' || input.value === '+63 ') input.value = '+63 ';
  });
}

function setOrgLookupMessage(message, state = '') {
  if (!orgLookupMessage) return;
  orgLookupMessage.textContent = message;
  orgLookupMessage.classList.remove('success', 'error');
  if (state) orgLookupMessage.classList.add(state);
}

function clearOrgRegistrationFields() {
  const orgNameInput = document.getElementById('org-name-input');
  const orgCourseInput = document.getElementById('org-course-input');
  const orgSectionInput = document.getElementById('org-section-input');
  const orgEmailInput = document.getElementById('org-email-input');
  const orgPhoneInput = document.getElementById('org-phone-input');
  const orgPasswordInput = document.getElementById('org-password-input');

  if (orgNameInput) orgNameInput.value = '';
  if (orgCourseInput) orgCourseInput.value = '';
  if (orgSectionInput) orgSectionInput.value = '';
  if (orgEmailInput) orgEmailInput.value = '';
  if (orgPhoneInput) orgPhoneInput.value = '';
  if (orgPasswordInput) orgPasswordInput.value = '';
}

function setOrgRegistrationVisibility(isVisible) {
  if (!orgRegistrationDetails) return;
  orgRegistrationDetails.hidden = !isVisible;
}

function resetOrgRegistrationState(message = 'Enter a registered student number to continue organization account registration.', state = '') {
  verifiedOrgStudentNumber = '';
  clearOrgRegistrationFields();
  setOrgRegistrationVisibility(false);
  setOrgLookupMessage(message, state);
}

function applyVerifiedOrgStudent(student) {
  const fullNameInput = document.getElementById('org-name-input');
  const courseInput = document.getElementById('org-course-input');
  const sectionInput = document.getElementById('org-section-input');
  const emailInput = document.getElementById('org-email-input');
  const phoneInput = document.getElementById('org-phone-input');

  if (fullNameInput) fullNameInput.value = student.full_name || '';
  if (courseInput) courseInput.value = student.course || '';
  if (sectionInput) sectionInput.value = student.section || '';
  if (emailInput) emailInput.value = student.email || '';
  if (phoneInput) phoneInput.value = student.phone ? normalizePhoneInput(student.phone) : '';

  orgLockedFieldIds.forEach((id) => {
    const input = document.getElementById(id);
    if (input) input.readOnly = true;
  });

  verifiedOrgStudentNumber = String(student.student_number || '').trim();
  setOrgRegistrationVisibility(true);
  setOrgLookupMessage('Student record found. Only organization and password fields can be changed.', 'success');
}

async function lookupOrganizationStudent(force = false) {
  const studentNumber = orgStudentNumberInput ? String(orgStudentNumberInput.value || '').trim() : '';
  if (!studentNumber) {
    resetOrgRegistrationState();
    return false;
  }

  if (!force && verifiedOrgStudentNumber && verifiedOrgStudentNumber === studentNumber) {
    return true;
  }

  const lookupToken = ++activeOrgLookupToken;
  verifiedOrgStudentNumber = '';
  clearOrgRegistrationFields();
  setOrgRegistrationVisibility(false);
  setOrgLookupMessage('Checking student number...', '');

  try {
    const response = await fetch('../api/auth/lookup-student.php', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ student_number: studentNumber })
    });
    const data = await response.json();

    if (lookupToken !== activeOrgLookupToken) return false;

    if (!data.ok || !data.student) {
      resetOrgRegistrationState(data.error || 'Student number is not registered as an active student account.', 'error');
      return false;
    }

    applyVerifiedOrgStudent(data.student);
    return true;
  } catch (error) {
    if (lookupToken !== activeOrgLookupToken) return false;
    resetOrgRegistrationState('Could not verify the student number right now.', 'error');
    return false;
  }
}

function setupOrganizationRegistrationLookup() {
  if (!orgStudentNumberInput) return;

  orgStudentNumberInput.addEventListener('input', () => {
    const currentValue = String(orgStudentNumberInput.value || '').trim();
    if (verifiedOrgStudentNumber && currentValue !== verifiedOrgStudentNumber) {
      resetOrgRegistrationState();
      return;
    }
    if (!currentValue) resetOrgRegistrationState();
  });

  orgStudentNumberInput.addEventListener('blur', () => {
    lookupOrganizationStudent();
  });

  orgStudentNumberInput.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    lookupOrganizationStudent(true);
  });
}

/* =====================
   DASHBOARD CHOICE MODAL
   ===================== */
const dashboardChoiceModal = document.getElementById('dashboardChoiceModal');
const goStudentDashboardBtn = document.getElementById('goStudentDashboardBtn');
const goOfficerDashboardBtn = document.getElementById('goOfficerDashboardBtn');
let pendingOrgLogin = null;

const officerOrganizationImages = {
  SSC: 'SSC.png',
  AISERS: 'AISERS.png',
  ELITECH: 'ELITECH.png',
  ILASSO: 'ILASSO.png',
  'AERO-ATSO': 'AEROATSO.png',
  AETSO: 'AET.png',
  AMTSO: 'AMT.png',
  RCYC: 'RCYC.png',
  CYC: 'CYC.png',
  SAGE: 'PSG.png',
  AERONAUTICA: 'AERONAUTICA.png'
};

function officerOrganizationImage(membership) {
  const code = String(membership.org_code || '').trim().toUpperCase();
  const image = officerOrganizationImages[code];
  return image
    ? `../assets/photos/studentDashboard/Organization/${image}`
    : '../assets/favicon.png';
}

function openDashboardChoiceModal() {
  document.getElementById('dashboardChoiceActions').hidden = false;
  document.getElementById('officerOrganizationChoice').hidden = true;
  dashboardChoiceModal?.querySelector('.dashboard-choice-box')?.classList.remove('choosing-organizations');
  if (dashboardChoiceModal) dashboardChoiceModal.classList.add('open');
}

function closeDashboardChoiceModal() {
  if (dashboardChoiceModal) dashboardChoiceModal.classList.remove('open');
  pendingOrgLogin = null;
}

if (dashboardChoiceModal) {
  dashboardChoiceModal.addEventListener('click', (e) => {
    if (e.target === dashboardChoiceModal) closeDashboardChoiceModal();
  });
}

if (goStudentDashboardBtn) {
  goStudentDashboardBtn.addEventListener('click', () => {
    if (!pendingOrgLogin) return;
    const { user, memberships, baseSession } = pendingOrgLogin;
    const session = {
      ...baseSession,
      login_role: 'student',
      active_org_id: null,
      active_org_name: null   // studentDashboard.js resolves from program_code via courseOrganizationMap
    };
    localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
    closeDashboardChoiceModal();
    window.location.href = '../student/';
  });
}

if (goOfficerDashboardBtn) {
  goOfficerDashboardBtn.addEventListener('click', async () => {
    if (!pendingOrgLogin) return;
    const memberships = Array.from(new Map((pendingOrgLogin.memberships || [])
      .filter(item => Number(item.org_id) > 0)
      .map(item => [Number(item.org_id), item])).values());
    if (memberships.length > 1) {
      const options = document.getElementById('officerOrganizationOptions');
      options.replaceChildren();
      memberships.forEach(membership => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'officer-organization-card';
        button.setAttribute('aria-label', `Open ${membership.org_name} officer dashboard`);
        const image = document.createElement('img');
        image.src = officerOrganizationImage(membership);
        image.alt = '';
        image.onerror = () => { image.src = '../assets/favicon.png'; image.onerror = null; };
        const title = document.createElement('span');
        title.className = 'officer-organization-card-title';
        title.textContent = membership.org_name;
        button.append(image, title);
        button.addEventListener('click', () => activateSelectedOfficerOrganization(membership));
        options.appendChild(button);
      });
      document.getElementById('dashboardChoiceActions').hidden = true;
      document.getElementById('officerOrganizationChoice').hidden = false;
      dashboardChoiceModal?.querySelector('.dashboard-choice-box')?.classList.add('choosing-organizations');
      options.querySelector('button')?.focus();
      return;
    }
    await activateSelectedOfficerOrganization(memberships[0]);
  });
}

let officerOrganizationActivating = false;
async function activateSelectedOfficerOrganization(selectedMembership) {
    if (!pendingOrgLogin || officerOrganizationActivating) return;
    const { baseSession } = pendingOrgLogin;
    if (!selectedMembership) { alert('Invalid organization selection.'); return; }
    officerOrganizationActivating = true;
    const session = {
      ...baseSession,
      login_role: 'org',
      active_org_id: selectedMembership.org_id,
      active_org_name: selectedMembership.org_name,
      active_role_name: selectedMembership.role_name
    };
    try {
      const resp = await fetch('../api/auth/activate-org.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ org_id: selectedMembership.org_id })
      });
      const data = await resp.json();
      if (!data.ok) {
        alert(data.error || 'Could not activate organization session.');
        return;
      }

      localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify({ ...session, ...data.session }));
      closeDashboardChoiceModal();
      window.location.href = '../officer/';
    } catch (err) {
      console.error('[activate-org] error:', err);
      alert('Could not activate organization session on server.');
    } finally {
      officerOrganizationActivating = false;
    }
}

/* =====================
   REGISTRATION HANDLERS
   ===================== */
const REGISTRATION_PASSWORD_GUIDES = {
  student: {
    passwordId: 'student-password-input',
    confirmId: 'student-confirm-password-input',
    requirementsId: 'student-password-input-requirements'
  },
  osa: {
    passwordId: 'osa-password-input',
    confirmId: 'osa-confirm-password-input',
    requirementsId: 'osa-password-input-requirements'
  },
  orgAdviser: {
    passwordId: 'org-adviser-password-input',
    confirmId: 'org-adviser-confirm-password-input',
    requirementsId: 'org-adviser-password-input-requirements'
  }
};

function setRegistrationFieldInvalid(inputOrId, invalid) {
  const input = typeof inputOrId === 'string' ? document.getElementById(inputOrId) : inputOrId;
  if (!input) return;
  input.classList.toggle('registration-field-invalid', invalid);
  input.setAttribute('aria-invalid', String(invalid));
  if (input.type === 'checkbox') {
    input.closest('.privacy-consent')?.classList.toggle('registration-field-invalid', invalid);
  }
}

function registrationFieldHasValue(input) {
  if (!input) return false;
  if (input.type === 'checkbox') return input.checked;
  const value = String(input.value || '').trim();
  if (input.type === 'tel') return value !== '' && value !== '+63';
  if (input.type === 'email' && value !== '') return input.checkValidity();
  return value !== '';
}

function validateRequiredRegistrationFields(fieldIds, focusInvalid = true) {
  const invalidFields = [];
  fieldIds.forEach((id) => {
    const input = document.getElementById(id);
    const invalid = !registrationFieldHasValue(input);
    setRegistrationFieldInvalid(input, invalid);
    if (invalid && input) invalidFields.push(input);
  });
  if (focusInvalid && invalidFields[0]) invalidFields[0].focus();
  return invalidFields.length === 0;
}

function updatePasswordRequirements(guideName, markInputs = false) {
  const guide = REGISTRATION_PASSWORD_GUIDES[guideName];
  if (!guide) return false;
  const passwordInput = document.getElementById(guide.passwordId);
  const confirmInput = document.getElementById(guide.confirmId);
  const requirements = document.getElementById(guide.requirementsId);
  if (!passwordInput || !confirmInput || !requirements) return false;

  const password = passwordInput.value || '';
  const confirmation = confirmInput.value || '';
  const rules = {
    length: Array.from(password).length >= 12,
    uppercase: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    match: confirmation !== '' && password === confirmation
  };

  Object.entries(rules).forEach(([name, passed]) => {
    requirements.querySelector(`[data-password-rule="${name}"]`)?.classList.toggle('password-rule-passed', passed);
  });

  const valid = Object.values(rules).every(Boolean);
  if (markInputs) {
    setRegistrationFieldInvalid(passwordInput, !(rules.length && rules.uppercase && rules.number));
    setRegistrationFieldInvalid(confirmInput, !rules.match);
  }
  return valid;
}

function validatePasswordPair(guideName, focusInvalid = false) {
  const valid = updatePasswordRequirements(guideName, true);
  if (!valid && focusInvalid) {
    const guide = REGISTRATION_PASSWORD_GUIDES[guideName];
    const passwordInput = document.getElementById(guide.passwordId);
    const confirmInput = document.getElementById(guide.confirmId);
    (passwordMeetsPolicy(passwordInput.value) ? confirmInput : passwordInput).focus();
  }
  return valid;
}

function hasPrivacyConsent(inputId) {
  const checkbox = document.getElementById(inputId);
  if (!checkbox || checkbox.checked) return true;
  setRegistrationFieldInvalid(checkbox, true);
  alert('Please acknowledge the Data Privacy Act notice before registering.');
  checkbox.focus();
  return false;
}

function validateStudentPassword(focusInvalid = false) {
  return validatePasswordPair('student', focusInvalid);
}

async function registerStudent() {
  const studentNumber = (document.getElementById('student-number-input') || {}).value?.trim() || '';
  const fullName = (document.getElementById('student-name-input') || {}).value?.trim() || '';
  const course = (document.getElementById('student-course-input') || {}).value?.trim() || '';
  const section = (document.getElementById('student-section-input') || {}).value?.trim() || '';
  const email = (document.getElementById('student-email-input') || {}).value?.trim() || '';
  const phone = normalizePhoneInput((document.getElementById('student-phone-input') || {}).value?.trim() || '');
  const password = (document.getElementById('student-password-input') || {}).value || '';
  const confirmPassword = (document.getElementById('student-confirm-password-input') || {}).value || '';

  if (!validateRequiredRegistrationFields([
    'student-number-input', 'student-name-input', 'student-course-input', 'student-section-input',
    'student-email-input', 'student-phone-input', 'student-password-input',
    'student-confirm-password-input', 'student-privacy-consent'
  ])) {
    alert('Please complete the Student registration fields highlighted in red.');
    return;
  }
  if (!studentNumber || !fullName || !course || !section || !email || !phone || !password || !confirmPassword) {
    alert('Please complete all Student registration fields.');
    return;
  }
  if (!isValidPhoneInput(phone)) {
    setRegistrationFieldInvalid('student-phone-input', true);
    alert('Phone number must be +63 followed by a space and 10 digits.');
    return;
  }
  if (!validateStudentPassword(true)) return;
  if (!hasPrivacyConsent('student-privacy-consent')) return;

  startRegistrationOtpFlow('student', email, studentNumber, 'student_registration', async (verificationToken) => {
    const submitted = await submitPendingRegistration({
      studentId: studentNumber,
      name: fullName,
      email,
      phone,
      password,
      course: normalizeCourse(course),
      yearSection: section,
      section: `${normalizeCourse(course)} ${section}`.trim(),
      requestedRole: 'student',
      requestedOrg: '',
      verificationToken
    });

    if (!submitted.ok) {
      alert(submitted.message);
      throw new Error(submitted.message);
    }

    alert('Registration submitted. Please wait for account approval in Accounts page.');
    toggleSlide();
  }, '', fullName);
}

async function registerOrgOfficer() {
  if (isOrganizationAdviserRegistration()) {
    await registerOrganizationAdviser();
    return;
  }
  const studentNumber = (document.getElementById('org-student-number-input') || {}).value?.trim() || '';
  const fullName = (document.getElementById('org-name-input') || {}).value?.trim() || '';
  const course = (document.getElementById('org-course-input') || {}).value?.trim() || '';
  const section = (document.getElementById('org-section-input') || {}).value?.trim() || '';
  const orgName = normalizeOrgName((document.getElementById('org-input') || {}).value?.trim() || '');
  const positionTitle = (document.getElementById('org-position-input') || {}).value?.trim() || '';
  const email = (document.getElementById('org-email-input') || {}).value?.trim() || '';
  const phone = normalizePhoneInput((document.getElementById('org-phone-input') || {}).value?.trim() || '');
  const password = (document.getElementById('org-password-input') || {}).value || '';

  if (!validateRequiredRegistrationFields(['org-input', 'org-position-input', 'org-student-number-input'])) {
    alert('Please complete the Organization registration fields highlighted in red.');
    return;
  }

  const verified = await lookupOrganizationStudent();
  if (!verified || verifiedOrgStudentNumber !== studentNumber) {
    alert('Enter a student number that is already registered as a student account first.');
    return;
  }

  if (!validateRequiredRegistrationFields([
    'org-input', 'org-position-input', 'org-student-number-input', 'org-name-input',
    'org-course-input', 'org-section-input', 'org-email-input', 'org-phone-input',
    'org-password-input', 'org-privacy-consent'
  ])) {
    alert('Please complete the Organization registration fields highlighted in red.');
    return;
  }

  if (!studentNumber || !fullName || !course || !section || !orgName || !positionTitle || !email || !password) {
    alert('Please complete all Organization registration fields.');
    return;
  }
  if (positionTitle.length > 120 || /[\u0000-\u001F\u007F]/.test(positionTitle)) {
    alert('Position title must be valid and 120 characters or fewer.');
    return;
  }
  if (phone && !isValidPhoneInput(phone)) {
    setRegistrationFieldInvalid('org-phone-input', true);
    alert('Phone number must be +63 followed by a space and 10 digits.');
    return;
  }
  if (!hasPrivacyConsent('org-privacy-consent')) return;

  startRegistrationOtpFlow('organization', email, studentNumber, 'org_registration', async (verificationToken) => {
    const submitted = await submitPendingRegistration({
      studentId: studentNumber,
      name: fullName,
      email,
      phone,
      password,
      course: normalizeCourse(course),
      yearSection: section,
      section: `${normalizeCourse(course)} ${section}`.trim(),
      requestedRole: 'org_officer',
      requestedOrg: orgName,
      requestedPosition: positionTitle,
      verificationToken
    });

    if (!submitted.ok) {
      alert(submitted.message);
      throw new Error(submitted.message);
    }

    alert('Officer registration submitted. Approve it first in Accounts page.');
    toggleSlide();
  }, '', '', password);
}

async function registerOrganizationAdviser() {
  const employeeNumber = (document.getElementById('org-adviser-employee-number-input') || {}).value?.trim() || '';
  const fullName = (document.getElementById('org-adviser-name-input') || {}).value?.trim() || '';
  const email = (document.getElementById('org-adviser-email-input') || {}).value?.trim() || '';
  const phone = normalizePhoneInput((document.getElementById('org-adviser-phone-input') || {}).value?.trim() || '');
  const password = (document.getElementById('org-adviser-password-input') || {}).value || '';
  const confirmPassword = (document.getElementById('org-adviser-confirm-password-input') || {}).value || '';
  const orgName = normalizeOrgName((document.getElementById('org-input') || {}).value?.trim() || '');

  if (!validateRequiredRegistrationFields([
    'org-input', 'org-position-input', 'org-adviser-employee-number-input', 'org-adviser-name-input',
    'org-adviser-email-input', 'org-adviser-phone-input', 'org-adviser-password-input',
    'org-adviser-confirm-password-input', 'org-privacy-consent'
  ])) {
    alert('Please complete the Organization Adviser fields highlighted in red.');
    return;
  }

  if (!employeeNumber || !fullName || !email || !phone || !password || !confirmPassword || !orgName) {
    alert('Please complete all Organization Adviser registration fields.');
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    alert('Enter a valid email address.');
    return;
  }
  if (!isValidPhoneInput(phone)) {
    setRegistrationFieldInvalid('org-adviser-phone-input', true);
    alert('Phone number must be +63 followed by a space and 10 digits.');
    return;
  }
  if (!validatePasswordPair('orgAdviser', true)) return;
  if (!hasPrivacyConsent('org-privacy-consent')) return;

  startRegistrationOtpFlow('organization adviser', email, employeeNumber, 'organization_adviser_registration', async (verificationToken) => {
    const submitted = await submitPendingRegistration({
      employeeNumber,
      name: fullName,
      email,
      phone,
      password,
      requestedRole: 'organization_adviser',
      requestedOrg: orgName,
      requestedPosition: 'Organization Adviser',
      verificationToken
    });
    if (!submitted.ok) {
      alert(submitted.message);
      throw new Error(submitted.message);
    }
    alert('Organization adviser registration submitted. Please wait for OSA approval.');
    toggleSlide();
  });
}

async function registerOsa() {
  const employeeNumber = (document.getElementById('osa-employee-number-input') || {}).value?.trim() || '';
  const fullName = (document.getElementById('osa-name-input') || {}).value?.trim() || '';
  const email = (document.getElementById('osa-email-input') || {}).value?.trim() || '';
  const phone = normalizePhoneInput((document.getElementById('osa-phone-input') || {}).value?.trim() || '');
  const password = (document.getElementById('osa-password-input') || {}).value || '';
  const confirmPassword = (document.getElementById('osa-confirm-password-input') || {}).value || '';

  if (!validateRequiredRegistrationFields([
    'osa-employee-number-input', 'osa-name-input', 'osa-email-input', 'osa-phone-input',
    'osa-password-input', 'osa-confirm-password-input', 'osa-privacy-consent'
  ])) {
    alert('Please complete the OSA registration fields highlighted in red.');
    return;
  }

  if (!employeeNumber || !fullName || !email || !phone || !password || !confirmPassword) {
    alert('Please complete all OSA registration fields.');
    return;
  }
  if (!isValidPhoneInput(phone)) {
    setRegistrationFieldInvalid('osa-phone-input', true);
    alert('Phone number must be +63 followed by a space and 10 digits.');
    return;
  }
  if (!validatePasswordPair('osa', true)) return;
  if (!hasPrivacyConsent('osa-privacy-consent')) return;

  if (!activeOsaInvitationToken) {
    alert('A valid OSA staff invitation is required.');
    return;
  }

  startRegistrationOtpFlow('OSA', email, employeeNumber, 'osa_registration', async (verificationToken) => {
    const parsedName = splitName(fullName);
    const btn = document.getElementById('osaRegisterBtn');
    if (btn) btn.disabled = true;

    try {
      const resp = await fetch('../api/auth/register-osa.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          employee_number: employeeNumber,
          first_name: parsedName.first_name,
          last_name: parsedName.last_name,
          email,
          phone,
          password,
          confirm_password: confirmPassword,
          verification_token: verificationToken,
          invitation_token: activeOsaInvitationToken,
          privacy_consent: true
        })
      });
      const data = await resp.json();
      if (!data.ok) {
        alert(data.error || 'Registration failed.');
        throw new Error(data.error || 'Registration failed.');
      }

      const { user, memberships } = data;
      const session = {
        user_id: user.user_id,
        account_type: 'osa_staff',
        is_primary_osa: false,
        display_name: `${user.first_name} ${user.last_name}`.trim(),
        email: user.email,
        student_number: null,
        employee_number: user.employee_number,
        phone: user.phone || null,
        profile_photo: user.profile_photo || null,
        authenticated_at: new Date().toISOString(),
        officer_memberships: memberships || [],
        login_role: 'osa',
        active_org_id: null,
        active_org_name: 'Office of Student Affairs',
        active_role_name: 'osa_staff'
      };
      localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
      sessionStorage.removeItem(OSA_INVITATION_SESSION_KEY);
      window.location.href = '../osa/';
    } catch (err) {
      console.error('[registerOsa] error:', err);
      alert('Could not connect to the server. Please try again.');
      throw err;
    } finally {
      if (btn) btn.disabled = false;
    }
  }, activeOsaInvitationToken);
}

async function initializeOsaInvitation() {
  const hashMatch = String(window.location.hash || '').match(/(?:^#|&)osa-invite=([a-f0-9]{64})(?:&|$)/i);
  if (hashMatch) {
    activeOsaInvitationToken = hashMatch[1].toLowerCase();
    sessionStorage.setItem(OSA_INVITATION_SESSION_KEY, activeOsaInvitationToken);
    history.replaceState(null, document.title, window.location.pathname + window.location.search);
  } else {
    activeOsaInvitationToken = sessionStorage.getItem(OSA_INVITATION_SESSION_KEY) || '';
  }
  if (!activeOsaInvitationToken) return;

  const status = document.getElementById('osa-invitation-status');
  try {
    const response = await fetch('../api/auth/osa-invitations/inspect.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invitation_token: activeOsaInvitationToken })
    });
    const data = await response.json();
    if (!response.ok || !data.ok || !data.invitation) {
      throw new Error(data.error || 'This OSA invitation is invalid or no longer available.');
    }
    const osaTab = document.getElementById('osaRegistrationTab');
    const employeeInput = document.getElementById('osa-employee-number-input');
    const emailInput = document.getElementById('osa-email-input');
    if (osaTab) osaTab.hidden = false;
    if (employeeInput) employeeInput.value = data.invitation.employee_number;
    if (emailInput) emailInput.value = data.invitation.email;
    if (status) {
      status.textContent = `Invitation verified for ${data.invitation.email}. Complete the locked OSA registration form.`;
      status.classList.add('success');
    }
    switchTab('osa');
    if (container && !container.classList.contains('right-panel-active')) toggleSlide();
  } catch (error) {
    activeOsaInvitationToken = '';
    sessionStorage.removeItem(OSA_INVITATION_SESSION_KEY);
    setLoginStatusMessage(error.message || 'This OSA invitation is invalid or no longer available.', false);
    if (status) {
      status.textContent = error.message;
      status.classList.add('error');
    }
  }
}

/* =====================
   LOGIN HANDLER
   ===================== */
const osaLoginOtpState = {
  identifier: '', password: '', challengeToken: '', resendTimer: null, isSubmitting: false
};

function getOsaLoginOtpInputs() {
  return Array.from(document.querySelectorAll('#osaLoginOtpInputs .otp-char'));
}

function getOsaLoginOtpValue() {
  return getOsaLoginOtpInputs().map((input) => String(input.value || '').trim()).join('');
}

function setOsaLoginOtpFeedback(message, isSuccess = false) {
  const feedback = document.getElementById('osaLoginOtpFeedback');
  if (!feedback) return;
  feedback.textContent = message || '';
  feedback.classList.toggle('success', !!isSuccess);
}

function resetOsaLoginOtpInputs() {
  getOsaLoginOtpInputs().forEach((input) => { input.value = ''; });
}

function openOsaLoginOtpModal() {
  document.getElementById('osaLoginOtpModal')?.classList.add('open');
}

function closeOsaLoginOtpModal() {
  document.getElementById('osaLoginOtpModal')?.classList.remove('open');
  if (osaLoginOtpState.resendTimer) clearInterval(osaLoginOtpState.resendTimer);
  Object.assign(osaLoginOtpState, {
    identifier: '', password: '', challengeToken: '', resendTimer: null, isSubmitting: false
  });
  resetOsaLoginOtpInputs();
  setOsaLoginOtpFeedback('');
}

function setupOsaLoginOtpInputs() {
  const inputs = getOsaLoginOtpInputs();
  inputs.forEach((input, index) => {
    input.addEventListener('input', () => {
      input.value = input.value.replace(/\D/g, '').slice(-1);
      setOsaLoginOtpFeedback('');
      if (input.value && index < inputs.length - 1) inputs[index + 1].focus();
    });
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Backspace' && !input.value && index > 0) inputs[index - 1].focus();
      if (event.key === 'ArrowLeft' && index > 0) inputs[index - 1].focus();
      if (event.key === 'ArrowRight' && index < inputs.length - 1) inputs[index + 1].focus();
      if (event.key === 'Enter') {
        event.preventDefault();
        verifyOsaLoginOtp();
      }
    });
    input.addEventListener('paste', (event) => {
      event.preventDefault();
      const digits = (event.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 6);
      digits.split('').forEach((digit, digitIndex) => { inputs[digitIndex].value = digit; });
      if (digits.length) inputs[Math.min(digits.length, 6) - 1]?.focus();
    });
  });
}

async function requestLogin(identifier, password, verificationToken = '', testingBypassOtp = false) {
  const response = await fetch('../api/auth/login.php', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      identifier,
      password,
      verification_token: verificationToken || undefined,
      testing_bypass_otp: !!testingBypassOtp
    })
  });
  const data = await response.json();
  if (!response.ok || !data.ok) {
    const error = new Error(data.error || 'Login failed. Please check your credentials.');
    error.retryAfter = Number(data.retry_after) || 0;
    throw error;
  }
  return data;
}

function beginOsaLoginOtp(identifier, password, data) {
  osaLoginOtpState.identifier = identifier;
  osaLoginOtpState.password = password;
  osaLoginOtpState.challengeToken = data.challenge_token || '';
  osaLoginOtpState.isSubmitting = false;
  resetOsaLoginOtpInputs();
  setOsaLoginOtpFeedback(data.message || 'Verification code sent.', true);
  const status = document.getElementById('osaLoginOtpStatus');
  if (status) status.textContent = 'Enter the 6-digit code sent to the email registered to this OSA account.';
  openOsaLoginOtpModal();
  startOtpResendCountdown(document.getElementById('osaLoginOtpResendBtn'), data.resend_after || 60, osaLoginOtpState);
  getOsaLoginOtpInputs()[0]?.focus();
}

async function resendOsaLoginOtp() {
  if (!osaLoginOtpState.identifier || !osaLoginOtpState.password || osaLoginOtpState.isSubmitting) return;
  osaLoginOtpState.isSubmitting = true;
  setOsaLoginOtpFeedback('Sending a new verification code...', true);
  try {
    const data = await requestLogin(osaLoginOtpState.identifier, osaLoginOtpState.password);
    if (!data.otp_required) throw new Error('OSA verification was not requested.');
    beginOsaLoginOtp(osaLoginOtpState.identifier, osaLoginOtpState.password, data);
  } catch (error) {
    setOsaLoginOtpFeedback(error.message || 'Could not resend the verification code.');
    if (error.retryAfter) {
      startOtpResendCountdown(document.getElementById('osaLoginOtpResendBtn'), error.retryAfter, osaLoginOtpState);
    }
  } finally {
    osaLoginOtpState.isSubmitting = false;
  }
}

async function verifyOsaLoginOtp() {
  const otp = getOsaLoginOtpValue();
  if (osaLoginOtpState.isSubmitting) return;
  if (!osaLoginOtpState.challengeToken) {
    setOsaLoginOtpFeedback('Request a new verification code.');
    return;
  }
  if (!/^\d{6}$/.test(otp)) {
    setOsaLoginOtpFeedback('Enter the complete 6-digit OTP.');
    return;
  }

  const verifyBtn = document.getElementById('osaLoginOtpVerifyBtn');
  osaLoginOtpState.isSubmitting = true;
  if (verifyBtn) verifyBtn.disabled = true;
  setOsaLoginOtpFeedback('Verifying OTP...', true);

  try {
    const response = await fetch('../api/auth/otp/verify.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ challenge_token: osaLoginOtpState.challengeToken, otp })
    });
    const verification = await response.json();
    if (!response.ok || !verification.ok) {
      throw new Error(verification.error || 'Invalid or expired verification code.');
    }
    const loginData = await requestLogin(
      osaLoginOtpState.identifier,
      osaLoginOtpState.password,
      verification.verification_token
    );
    closeOsaLoginOtpModal();
    completeAuthenticatedLogin(loginData);
  } catch (error) {
    setOsaLoginOtpFeedback(error.message || 'Could not verify the code.');
  } finally {
    osaLoginOtpState.isSubmitting = false;
    if (verifyBtn) verifyBtn.disabled = false;
  }
}

function completeAuthenticatedLogin(data) {
  const { user, memberships } = data;
  const baseSession = {
    user_id: user.user_id,
    account_type: user.account_type,
    is_primary_osa: !!user.is_primary_osa,
    display_name: `${user.first_name} ${user.last_name}`.trim(),
    email: user.email,
    student_number: user.student_number || null,
    employee_number: user.employee_number || null,
    phone: user.phone || null,
    profile_photo: user.profile_photo || null,
    authenticated_at: new Date().toISOString(),
    officer_memberships: memberships || [],
    program_id: user.program_id || null,
    program_code: user.program_code || null,
    section: user.section || null,
    mapped_org_id: user.mapped_org_id || null,
    mapped_org_name: user.mapped_org_name || null
  };

  if (data.legacyProfile) localStorage.setItem(LEGACY_STUDENT_PROFILE_KEY, JSON.stringify(data.legacyProfile));

  if (user.account_type === 'osa_staff') {
    localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify({
      ...baseSession,
      login_role: 'osa',
      active_org_id: null,
      active_org_name: 'Office of Student Affairs',
      active_role_name: 'osa_staff'
    }));
    window.location.href = '../osa/';
    return;
  }

  if (user.account_type === 'organization_adviser') {
    activateOrganizationAdviserDashboard(memberships, baseSession);
    return;
  }

  if (!memberships || memberships.length === 0) {
    localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify({
      ...baseSession,
      login_role: 'student',
      active_org_id: null,
      active_org_name: null
    }));
    window.location.href = '../student/';
    return;
  }

  pendingOrgLogin = { user, memberships, baseSession };
  openDashboardChoiceModal();
}

async function activateOrganizationAdviserDashboard(memberships, baseSession) {
  const selected = Array.isArray(memberships) ? memberships[0] : null;
  if (!selected) {
    alert('This organization adviser account has no active organization assignment. Contact the OSA.');
    return;
  }
  const response = await fetch('../api/auth/activate-org.php', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ org_id: Number(selected.org_id) })
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || 'Could not activate the adviser organization.');
  localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify({ ...baseSession, ...data.session }));
  window.location.href = '../officer/';
}

async function handleLogin(testingBypassOtp = false) {
  const identifier = (document.getElementById('loginIdentifier') || {}).value?.trim() || '';
  const password = (document.getElementById('loginPassword') || {}).value || '';

  if (!identifier || !password) {
    alert('Please enter your email / ID and password.');
    return;
  }

  const loginBtn = document.getElementById('loginBtn');
  if (loginBtn) loginBtn.disabled = true;

  try {
    const data = await requestLogin(identifier, password, '', testingBypassOtp === true);
    if (data.otp_required) {
      beginOsaLoginOtp(identifier, password, data);
      return;
    }

    const { user, memberships } = data;

    // Base session shape (same structure the dashboards expect)
    const baseSession = {
      user_id: user.user_id,
      account_type: user.account_type,
      is_primary_osa: !!user.is_primary_osa,
      display_name: `${user.first_name} ${user.last_name}`.trim(),
      email: user.email,
      student_number: user.student_number || null,
      employee_number: user.employee_number || null,
      phone: user.phone || null,
      profile_photo: user.profile_photo || null,
      authenticated_at: new Date().toISOString(),
      officer_memberships: memberships || [],
      // Extra fields used by studentDashboard.js buildCurrentStudentProfile
      program_id: user.program_id || null,
      program_code: user.program_code || null,
      section: user.section || null,
      mapped_org_id: user.mapped_org_id || null,
      mapped_org_name: user.mapped_org_name || null
    };

    if (data.legacyProfile) {
      localStorage.setItem(LEGACY_STUDENT_PROFILE_KEY, JSON.stringify(data.legacyProfile));
    }

    // OSA staff — go straight to OSA dashboard
    if (user.account_type === 'osa_staff') {
      const session = {
        ...baseSession,
        login_role: 'osa',
        active_org_id: null,
        active_org_name: 'Office of Student Affairs',
        active_role_name: 'osa_staff'
      };
      localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
      window.location.href = '../osa/';
      return;
    }

    if (user.account_type === 'organization_adviser') {
      await activateOrganizationAdviserDashboard(memberships, baseSession);
      return;
    }

    // Student with no officer memberships — student dashboard only
    if (!memberships || memberships.length === 0) {
      const session = {
        ...baseSession,
        login_role: 'student',
        active_org_id: null,
        active_org_name: null
      };
      localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
      window.location.href = '../student/';
      return;
    }

    // Has officer memberships — show the dashboard choice modal
    pendingOrgLogin = { user, memberships, baseSession };

    openDashboardChoiceModal();

  } catch (err) {
    console.error('[handleLogin] error:', err);
    alert(err.message || 'Could not connect to the server. Make sure XAMPP is running.');
  } finally {
    if (loginBtn) loginBtn.disabled = false;
  }
}

/* =====================
   INIT BINDINGS
   ===================== */
document.addEventListener('DOMContentLoaded', () => {
  getAuthDb();
  setupPasswordVisibilityToggles();
  setupPhoneInput('student-phone-input');
  setupPhoneInput('org-phone-input');
  setupPhoneInput('org-adviser-phone-input');
  setupPhoneInput('osa-phone-input');
  setupOrganizationRegistrationLookup();
  resetOrgRegistrationState();
  updateOrganizationRegistrationMode();
  setupForgotPasswordFlow();
  setupRegistrationOtpFlow();
  setupOsaLoginOtpInputs();
  initializeOsaInvitation();

  const studentRegisterBtn = document.getElementById('studentRegisterBtn');
  const orgRegisterBtn = document.getElementById('orgRegisterBtn');
  const osaRegisterBtn = document.getElementById('osaRegisterBtn');
  const loginBtn = document.getElementById('loginBtn');
  const localOsaOtpBypassBtn = document.getElementById('localOsaOtpBypassBtn');

  const studentForm = document.getElementById('form-student');
  const orgForm = document.getElementById('form-org');
  const osaForm = document.getElementById('form-osa');
  const loginForm = document.getElementById('loginForm');

  Object.entries(REGISTRATION_PASSWORD_GUIDES).forEach(([guideName, guide]) => {
    [guide.passwordId, guide.confirmId].forEach((id) => {
      document.getElementById(id)?.addEventListener('input', () => {
        updatePasswordRequirements(guideName);
        setRegistrationFieldInvalid(id, false);
      });
    });
    updatePasswordRequirements(guideName);
  });

  document.querySelectorAll('.reg-fields input[required]').forEach((input) => {
    const eventName = input.type === 'checkbox' ? 'change' : 'input';
    input.addEventListener(eventName, () => {
      if (registrationFieldHasValue(input)) setRegistrationFieldInvalid(input, false);
    });
  });
  if (studentForm) studentForm.addEventListener('submit', (event) => {
    event.preventDefault();
    registerStudent();
  });
  if (studentRegisterBtn) studentRegisterBtn.addEventListener('click', registerStudent);
  if (orgRegisterBtn) orgRegisterBtn.addEventListener('click', registerOrgOfficer);
  if (osaRegisterBtn) osaRegisterBtn.addEventListener('click', registerOsa);
  if (loginBtn) loginBtn.addEventListener('click', handleLogin);
  if (localOsaOtpBypassBtn) {
    const localHosts = new Set(['localhost', '127.0.0.1', '::1']);
    localOsaOtpBypassBtn.hidden = !localHosts.has(window.location.hostname.toLowerCase());
    localOsaOtpBypassBtn.addEventListener('click', () => handleLogin(true));
  }
  document.getElementById('osaLoginOtpVerifyBtn')?.addEventListener('click', verifyOsaLoginOtp);
  document.getElementById('osaLoginOtpResendBtn')?.addEventListener('click', resendOsaLoginOtp);

  const enterSubmit = (form, action) => {
    if (!form) return;
    form.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        action();
      }
    });
  };

  enterSubmit(studentForm, registerStudent);
  enterSubmit(orgForm, registerOrgOfficer);
  enterSubmit(osaForm, registerOsa);
  enterSubmit(loginForm, handleLogin);
});

